"""Entry point for the chunking + retrieval-evaluation pipeline.

Usage:
    python main.py chunk            # Component A: chunk, embed, build FAISS index
    python main.py evaluate         # Component B: generate questions, query, report metrics
    python main.py all              # both, in order
    python main.py all --mock      # offline validation run (no credentials / network)
"""
from __future__ import annotations

import argparse
import os
import sys

from dotenv import load_dotenv

from models import REQUIRED_ENV_VARS, TokenCounter, load_config, make_client
from chunker import StructureAwareChunker
from evaluator import RetrievalEvaluator


def main() -> int:
    parser = argparse.ArgumentParser(description="Structure-aware chunking and retrieval evaluation")
    parser.add_argument("command", choices=["chunk", "evaluate", "all"])
    parser.add_argument("--config", default="config.json", help="path to config.json")
    parser.add_argument("--mock", action="store_true",
                        help="use the offline mock client (pipeline validation only)")
    args = parser.parse_args()

    load_dotenv()
    config = load_config(args.config)

    if not args.mock:
        missing = [v for v in REQUIRED_ENV_VARS if not os.environ.get(v)]
        if missing:
            print("Missing required environment variables (set them in .env or the shell):")
            for v in missing:
                print(f"  - {v}")
            print("Or run with --mock for an offline validation pass.")
            return 1

    counter = TokenCounter()
    client = make_client(config, mock=args.mock)
    if args.mock:
        print("[main] MOCK MODE: hashed lexical embeddings + template questions "
              "(validates mechanics, not semantic quality)\n")

    if args.command in ("chunk", "all"):
        StructureAwareChunker(config, counter, client).run()
    if args.command in ("evaluate", "all"):
        RetrievalEvaluator(config, counter, client).run()
    return 0


if __name__ == "__main__":
    sys.exit(main())
