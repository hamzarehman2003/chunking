"""Shared infrastructure for Components A and B.

Holds the config loader, the gpt2 TokenCounter, R2D2 OAuth authentication and
the Stellar API client (GTE embeddings + Mistral chat completions), plus an
offline mock client used to validate the pipeline without network access.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
from pathlib import Path

import numpy as np
import requests
from tokenizers import Tokenizer

DEFAULT_TOKENIZER = str(Path(__file__).parent / 'gpt2_tokenizer' / 'gpt2_tokenizer.json')

REQUIRED_ENV_VARS = [
    "R2D2__TOKEN_URL", "R2D2__SCOPE", "R2D2__GRANT_TYPE",
    "R2D2__CLIENT_ID", "R2D2__CLIENT_SECRET", "SSL_CERT_FILE",
]


def load_config(path: str = "config.json") -> dict:
    with open(path, encoding="utf-8") as f:
        return json.load(f)


class TokenCounter:
    def __init__(self, tokenizer_path: str = DEFAULT_TOKENIZER):
        self.tok = Tokenizer.from_file(tokenizer_path)

    def count(self, text: str) -> int:
        return len(self.tok.encode(text).ids) if text else 0


def get_token():
    payload = {
        "client_id": os.environ["R2D2__CLIENT_ID"],
        "client_secret": os.environ["R2D2__CLIENT_SECRET"],
        "grant_type": os.environ["R2D2__GRANT_TYPE"],
        "scope": os.environ["R2D2__SCOPE"],
    }

    resp = requests.post(
        os.environ["R2D2__TOKEN_URL"],
        data=payload,
        verify=os.environ.get("SSL_CERT_FILE") or True,
    )

    if resp.ok:
        return resp.json().get("access_token")
    else:
        print(f"Failed to obtain token {resp.status_code} due to {resp.reason}")
        return None


class StellarClient:
    """GTE embeddings and Mistral chat completions via the Stellar endpoint."""

    def __init__(self, chunking_config: dict, eval_config: dict | None = None):
        self.chunking_config = chunking_config
        self.eval_config = eval_config or {}
        self.token = get_token()
        if not self.token:
            raise RuntimeError("Could not obtain an access token - check the R2D2__* environment variables.")

    def _post(self, path: str, body: dict) -> requests.Response:
        url = f"{self.chunking_config['endpoint']}{path}"
        verify = os.environ.get("REQUESTS__CA_BUNDLE") or os.environ.get("SSL_CERT_FILE") or True
        headers = {"Content-Type": "application/json", "Authorization": f"Bearer {self.token}"}
        response = requests.post(url, headers=headers, json=body, verify=verify, timeout=120)
        if response.status_code == 401:  # token expired -> refresh once and retry
            self.token = get_token()
            headers["Authorization"] = f"Bearer {self.token}"
            response = requests.post(url, headers=headers, json=body, verify=verify, timeout=120)
        return response

    def embed(self, texts: list[str]) -> np.ndarray:
        all_vecs: list[list[float]] = []
        batch_size = int(self.chunking_config.get("embedding_batch_size", 32))
        for i in range(0, len(texts), batch_size):
            batch = texts[i:i + batch_size]
            response = self._post("stellar/v1/embeddings", {
                "model": self.chunking_config["embedding_model"],
                "input": batch,
            })
            if response.status_code != 200:
                raise RuntimeError(f"Embedding request failed: {response.status_code} {response.text[:300]}")
            data = sorted(response.json()["data"], key=lambda x: x["index"])
            all_vecs.extend([item["embedding"] for item in data])
        return np.asarray(all_vecs, dtype="float32")

    def chat(self, messages: list[dict]) -> str:
        response = self._post("stellar/v1/chat/completions", {
            "model": self.eval_config["model"],
            "messages": messages,
            "temperature": self.eval_config.get("temperature", 0.7),
            "max_tokens": self.eval_config.get("max_tokens", 4096),
            "stream": self.eval_config.get("stream", False),
        })
        if response.status_code != 200:
            raise RuntimeError(f"Chat request failed: {response.status_code} {response.text[:300]}")
        return response.json()["choices"][0]["message"]["content"]


# --------------------------------------------------------------------------
# Offline mock client (pipeline validation only - no network, no credentials)
# --------------------------------------------------------------------------

_STOPWORDS = {
    "the", "and", "for", "are", "was", "were", "with", "that", "this", "from", "have",
    "has", "had", "will", "would", "can", "could", "should", "which", "their", "its",
    "also", "been", "into", "than", "then", "them", "they", "when", "where", "while",
    "each", "such", "more", "most", "other", "some", "these", "those", "not", "but",
    "all", "any", "may", "per", "our", "out", "over", "under", "about", "after",
}

_WORD_RE = re.compile(r"[a-z0-9]+")
_MOCK_SENT_RE = re.compile(r"(?<=[.!?])\s+")


class MockStellarClient:
    """Drop-in replacement for StellarClient that works fully offline.

    Embeddings are hashed bag-of-words vectors (lexical similarity only) and
    question generation is template-based, so retrieval quality numbers from a
    mock run only validate the pipeline mechanics - not real semantic quality.
    """

    DIM = 768

    def __init__(self, chunking_config: dict, eval_config: dict | None = None):
        self.chunking_config = chunking_config
        self.eval_config = eval_config or {}

    def embed(self, texts: list[str]) -> np.ndarray:
        vecs = np.zeros((len(texts), self.DIM), dtype="float32")
        for row, text in enumerate(texts):
            for word in _WORD_RE.findall(text.lower()):
                if len(word) < 3 or word in _STOPWORDS:
                    continue
                digest = int(hashlib.md5(word.encode()).hexdigest(), 16)
                vecs[row, digest % self.DIM] += 1.0
                vecs[row, (digest >> 64) % self.DIM] += 1.0
        norms = np.linalg.norm(vecs, axis=1, keepdims=True)
        norms[norms == 0] = 1.0
        return vecs / norms

    def chat(self, messages: list[dict]) -> str:
        # Recover the page text from the evaluator's prompt and build questions
        # from its own sentences so lexical retrieval has a fair chance.
        user_msg = messages[-1]["content"]
        page_text = user_msg.split("PAGE TEXT:", 1)[-1].strip()
        sentences = [s.strip() for s in _MOCK_SENT_RE.split(page_text) if len(s.split()) >= 6]

        def keywords(text: str, n: int) -> str:
            words = [w for w in _WORD_RE.findall(text.lower()) if len(w) >= 3 and w not in _STOPWORDS]
            return " ".join(words[:n])

        specific = []
        for sent in sentences:
            template = ("What value or figure does the document mention regarding {kw}?"
                        if any(ch.isdigit() for ch in sent)
                        else "What does the document state about {kw}?")
            specific.append(template.format(kw=keywords(sent, 8)))
            if len(specific) >= 3:
                break

        broad = [
            f"What is the main theme of the section discussing {keywords(page_text, 6)}?",
            f"What overall conclusion can be drawn about {keywords(page_text, 4)}?",
        ]
        return json.dumps({"specific": specific, "broad": broad})


def make_client(config: dict, mock: bool):
    cls = MockStellarClient if mock else StellarClient
    return cls(config["chunking"], config.get("evaluation"))
