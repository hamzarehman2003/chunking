# Solar Microgrid Feasibility Report

### Page: 1

## Executive Summary

This report evaluates the technical and financial feasibility of deploying a 2.4 megawatt solar microgrid at the Riverside industrial campus in Alameda County. The assessment was commissioned by Meridian Energy Partners in March 2025 and covers site conditions, system design, financial modelling, and regulatory compliance. The proposed system combines 5,800 photovoltaic panels with a 4.2 megawatt-hour lithium iron phosphate battery energy storage system, allowing the campus to operate independently from the utility grid for up to nine hours during outages.

The analysis concludes that the project is financially viable under all three modelled scenarios. The base case projects a levelized cost of energy of 6.8 cents per kilowatt-hour, which is 42 percent below the current commercial utility tariff of 11.7 cents. Annual energy production is estimated at 4,100 megawatt-hours, offsetting approximately 78 percent of the campus's current consumption. The total installed cost is projected at 4.9 million dollars, with a simple payback period of 7.2 years and an internal rate of return of 11.4 percent over the 25-year system life.

Three risks dominate the sensitivity analysis. First, interconnection delays at the Pacific Gas and Electric substation could postpone commissioning by up to fourteen months. Second, tariff reform under consideration by the state regulator could reduce export compensation by 30 percent, extending payback to 8.9 years. Third, battery degradation beyond the warranted 70 percent capacity retention at year ten would require a mid-life augmentation costing an estimated 620,000 dollars. Mitigation strategies for each risk are detailed in Section 4 of this report.

The report recommends proceeding to the detailed engineering phase in the fourth quarter of 2025, contingent on securing the federal investment tax credit at the 30 percent level and executing a power purchase agreement with the campus's two anchor tenants, Halstrom Logistics and Vexler Manufacturing.

### Page: 2

## Site Assessment

### Climate Conditions

The Riverside campus receives an annual average of 5.6 peak sun hours per day, with seasonal variation from 3.1 hours in December to 7.9 hours in July. Historical weather data from the Oakland International Airport station, located 11 kilometers northwest of the site, shows an average of 62 fully overcast days per year. Ambient temperatures range from a winter low of 3 degrees Celsius to a summer high of 38 degrees Celsius, well within the operating envelope of the selected photovoltaic modules.

Wind loading at the site is moderate, with a 50-year design gust of 145 kilometers per hour. The site lies outside the 100-year flood plain and carries a low wildfire risk rating from CAL FIRE. Seismic design category D applies, requiring flexible conduit connections and reinforced racking foundations throughout the array.

### Land and Structural Requirements

The proposed layout occupies 6.5 hectares of the campus's southern parcel, currently used for overflow parking. Ground-mounted arrays will use driven-pile foundations at a tilt angle of 22 degrees, oriented 8 degrees west of true south to align with the parcel boundary. Geotechnical borings at twelve locations found stiff clay soils with adequate bearing capacity at 2.5 meters depth.

Two of the campus's five warehouse roofs were also assessed for rooftop arrays. The northern warehouse, built in 2019, can support an additional dead load of 18 kilograms per square meter and will host 640 panels. The older southern warehouse requires structural reinforcement estimated at 210,000 dollars and was excluded from the base design.

### Page: 3

## System Design

The microgrid consists of four main subsystems: the photovoltaic array, the battery energy storage system, the power conversion layer, and the microgrid controller. The design prioritizes islanding capability, allowing seamless transition from grid-connected to standalone operation within 80 milliseconds of a detected outage.

### Table-3.1

| Component | Specification | Quantity | Unit Cost (USD) |
|---|---|---|---|
| PV module, 415 W bifacial | Trina Vertex TSM-415 | 5,800 | 148 |
| String inverter, 125 kW | SMA Sunny Highpower | 18 | 9,400 |
| Battery rack, 233 kWh LFP | CATL EnerOne | 18 | 61,000 |
| Microgrid controller | Schneider EcoStruxure | 1 | 185,000 |
| Transformer, 2.5 MVA | ABB dry-type | 2 | 96,000 |

### Inverter and Conversion Layer

Eighteen string inverters aggregate the photovoltaic output at 800 volts DC and convert it to 480 volts AC for campus distribution. The inverters were selected for their 98.7 percent peak efficiency and native support for the IEEE 2030.5 communication standard required by the utility for export control. A separate 2.0 megawatt bidirectional converter manages battery charge and discharge, enabling the storage system to provide frequency response services to the wholesale market during grid-connected operation.

### Figure-3.1

Figure 3.1 shows the single-line diagram of the proposed microgrid. The photovoltaic array feeds two combiner groups into the DC bus, while the battery system connects through the bidirectional converter to the main 480-volt switchgear. The point of common coupling with the utility sits behind a motorized breaker that opens automatically when the microgrid controller detects a grid disturbance, isolating the campus within 80 milliseconds. Critical loads, including the cold-storage warehouse and the data room, are served from a dedicated priority bus that the controller sheds last during extended islanded operation.

### Page: 4

## Financial Analysis

The financial model assumes a 25-year analysis horizon, a 7.5 percent nominal discount rate, and 2.4 percent annual utility tariff escalation. Capital expenditure totals 4.9 million dollars: 2.6 million for the photovoltaic system, 1.7 million for storage, and 600,000 for interconnection, controls, and soft costs. The federal investment tax credit at 30 percent reduces the net owner cost to 3.43 million dollars.

Under the base case, year-one savings reach 512,000 dollars, comprising 342,000 dollars of avoided energy purchases, 96,000 dollars of demand-charge reduction, and 74,000 dollars of wholesale market revenue from frequency response. The model projects cumulative nominal savings of 16.8 million dollars over the analysis horizon.

The downside scenario applies the proposed export tariff reform, a 15 percent capital cost overrun, and battery augmentation at year ten. Even under these combined stresses the project retains a positive net present value of 380,000 dollars and an internal rate of return of 8.1 percent, supporting the conclusion that the investment case is robust.

### Figure-4.1

Figure 4.1 presents the cumulative discounted cash flow for the three scenarios. The base case crosses breakeven in year eight, the upside case in year six, and the downside case in year eleven. All three curves converge toward positive territory well before the end of the 25-year horizon, with terminal net present values of 2.9 million, 4.4 million, and 0.38 million dollars respectively.

### Page: 5

## Conclusions and Recommendations

The feasibility assessment supports proceeding with the Riverside solar microgrid. The site offers favorable solar resource, suitable land, and a load profile well matched to solar-plus-storage economics. The financial case clears Meridian Energy Partners' hurdle rate of 8 percent in every modelled scenario, and the microgrid's islanding capability addresses the campus tenants' stated requirement for nine hours of outage ride-through.

Three actions are recommended before final investment decision. First, submit the interconnection application to Pacific Gas and Electric no later than August 2025 to hold a queue position ahead of the anticipated cluster-study backlog. Second, execute term sheets for the power purchase agreement with Halstrom Logistics and Vexler Manufacturing at the proposed rate of 9.2 cents per kilowatt-hour with 2 percent annual escalation. Third, commission a firm-price engineering, procurement, and construction tender to retire the capital cost uncertainty reflected in the downside scenario.

Subject to these actions, detailed engineering should begin in the fourth quarter of 2025, with commissioning targeted for the first quarter of 2027.
