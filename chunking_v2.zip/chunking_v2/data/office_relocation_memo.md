### Page: 1

The facilities committee has completed its review of the three candidate sites for the headquarters relocation and recommends the Harborview Tower at 400 Marina Boulevard. The building offers 8,200 square meters of contiguous space across floors eleven through fourteen, with an asking rent of 38 dollars per square meter per month on a ten-year term. The landlord, Cascadia Property Group, has agreed to a fourteen-month fit-out allowance and two five-year renewal options at market rate with a 5 percent cap on the first reset.

The runner-up site, the Exchange Building on Fifth Avenue, offered a lower rent of 33 dollars per square meter but could not provide contiguous floors before 2028. The committee scored Harborview higher on transit access, with the Marina light-rail station 250 meters from the lobby and fourteen bus routes within a five-minute walk. Employee commute modelling shows the median door-to-door time falling from 41 minutes at the current site to 33 minutes at Harborview.

The relocation budget is set at 6.2 million dollars, of which 3.9 million covers fit-out construction, 1.1 million covers furniture and audiovisual equipment, 700,000 covers moving and decommissioning, and 500,000 is held as contingency. Finance has confirmed the budget fits within the approved capital plan for fiscal year 2026 without displacing other projects.

### Page: 2

The proposed timeline targets lease execution by 15 September 2026, design completion by January 2027, and construction from February through August 2027. The physical move would occur over two weekends in September 2027, with the engineering and customer support teams moving first, followed by corporate functions. The current lease at Pioneer Plaza expires on 31 December 2027, providing a three-month buffer for decommissioning and restoration obligations.

Employee workspace standards will change with the move. The new plan provides 1.2 workstations per employee on a neighborhood model, replacing the current fixed-desk arrangement, and increases meeting-room capacity by 40 percent to 62 rooms. A staff survey conducted in May 2026 with 1,340 responses showed 71 percent support for the neighborhood model, with the strongest concerns centred on storage space and quiet-room availability. The design brief allocates 480 lockers and eighteen dedicated focus rooms in response.

The committee asks the executive team to approve the Harborview lease terms at the July meeting. A decision after August would forfeit the negotiated fit-out allowance, which Cascadia has held open for ninety days, and would push occupancy into the second quarter of 2028 given contractor lead times.
