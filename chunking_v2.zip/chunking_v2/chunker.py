"""Component A: structure-aware, parent-child ("small-to-big") chunker.

Parses extractor Markdown (page tags, heading hierarchy, table/figure blocks)
into large parent sections and small sentence-packed child chunks. Children
are embedded (breadcrumb + body) and stored in a single FAISS index covering
all input documents; parents are kept aside as the context unit returned at
query time.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path

import faiss

HEADING_RE = re.compile(r"^(#{1,6})\s+(.+?)\s*$")
ATOMIC_TITLE_RE = re.compile(r"^(table|figure)\b[-_.:\s]?", re.IGNORECASE)
SENTENCE_RE = re.compile(r"(?<=[.!?])\s+(?=[\"'(\[]?[A-Z0-9])")


@dataclass
class Block:
    kind: str                 # text | table | figure
    text: str
    page: int
    path: tuple[str, ...]     # heading titles, outermost first


@dataclass
class Sentence:
    text: str
    page: int
    tokens: int


class StructureAwareChunker:
    def __init__(self, config: dict, counter, client):
        self.cfg = config["chunking"]
        self.counter = counter
        self.client = client
        self.page_re = self.compile_page_pattern(self.cfg["page_tag_pattern"])

    @staticmethod
    def compile_page_pattern(pattern: str) -> re.Pattern:
        """Turn a tag pattern like '### Page: {n}' into a line-matching regex."""
        return re.compile(r"^\s*" + re.escape(pattern).replace(re.escape("{n}"), r"(\d+)") + r"\s*$")

    @staticmethod
    def parse_pages(text: str, page_re: re.Pattern) -> list[tuple[int, str]]:
        """Split raw markdown into (page_no, page_text) pairs; reused by Component B."""
        pages: list[tuple[int, str]] = []
        page_no, buf = None, []

        def flush():
            body = "\n".join(buf).strip()
            if body and page_no is not None:
                pages.append((page_no, body))

        for line in text.splitlines():
            m = page_re.match(line)
            if m:
                flush()
                page_no, buf = int(m.group(1)), []
            else:
                buf.append(line)
        flush()
        if not pages and text.strip():   # document without page tags
            pages.append((1, text.strip()))
        return pages

    # ------------------------------------------------------------------
    # Parsing: markdown -> blocks -> sections
    # ------------------------------------------------------------------

    def _parse_blocks(self, text: str) -> list[Block]:
        blocks: list[Block] = []
        para: list[str] = []
        page = 1
        stack: list[tuple[int, str]] = []           # (heading level, title)
        atomic: list[str] | None = None             # lines of an open table/figure block
        atomic_kind = ""
        atomic_page = 1

        def path() -> tuple[str, ...]:
            return tuple(title for _, title in stack)

        def flush_para():
            nonlocal para
            body = "\n".join(para).strip()
            if body:
                blocks.append(Block("text", body, page, path()))
            para = []

        def flush_atomic():
            nonlocal atomic
            if atomic is not None:
                body = "\n".join(atomic).strip()
                if body:
                    blocks.append(Block(atomic_kind, body, atomic_page, path()))
            atomic = None

        for line in text.splitlines():
            m_page = self.page_re.match(line)
            if m_page:
                flush_para()
                flush_atomic()
                page = int(m_page.group(1))
                continue
            m_head = HEADING_RE.match(line)
            if m_head:
                flush_para()
                flush_atomic()
                level, title = len(m_head.group(1)), m_head.group(2).strip()
                if ATOMIC_TITLE_RE.match(title):
                    atomic_kind = "table" if title.lower().startswith("table") else "figure"
                    atomic, atomic_page = [title], page
                else:
                    while stack and stack[-1][0] >= level:
                        stack.pop()
                    stack.append((level, title))
                continue
            if atomic is not None:                  # table/figure body runs to next heading/page tag
                atomic.append(line)
            elif line.strip():
                para.append(line.rstrip())
            else:
                flush_para()
        flush_para()
        flush_atomic()
        return blocks

    @staticmethod
    def _group_sections(blocks: list[Block]) -> list[tuple[tuple[str, ...], list[Block]]]:
        """Group contiguous blocks that share the same section path."""
        sections: list[tuple[tuple[str, ...], list[Block]]] = []
        for block in blocks:
            if not sections or sections[-1][0] != block.path:
                sections.append((block.path, []))
            sections[-1][1].append(block)
        return sections

    # ------------------------------------------------------------------
    # Parents: pack section blocks up to parent_max_tokens (never split a
    # paragraph/table/figure across two parents)
    # ------------------------------------------------------------------

    def _build_parents(self, sections, doc_id: str) -> list[dict]:
        parents: list[dict] = []

        def flush(path, blks):
            if not blks:
                return
            parents.append({
                "parent_id": f"{doc_id}::p{len(parents):04d}",
                "doc_id": doc_id,
                "section_path": " > ".join(path),
                "text": "\n\n".join(b.text for b in blks),
                "page_start": min(b.page for b in blks),
                "page_end": max(b.page for b in blks),
                "token_count": sum(self.counter.count(b.text) for b in blks),
                "children": [],
                "_blocks": blks,          # transient, dropped before serialization
            })

        for path, blks in sections:
            cur, cur_tokens = [], 0
            for block in blks:
                block_tokens = self.counter.count(block.text)
                if cur and cur_tokens + block_tokens > self.cfg["parent_max_tokens"]:
                    flush(path, cur)
                    cur, cur_tokens = [], 0
                cur.append(block)
                cur_tokens += block_tokens
            flush(path, cur)
        return parents

    # ------------------------------------------------------------------
    # Children: sentence packing with overlap and fragment merging
    # ------------------------------------------------------------------

    def _split_sentences(self, block: Block) -> list[Sentence]:
        flat = " ".join(block.text.split())
        return [Sentence(s, block.page, self.counter.count(s))
                for s in SENTENCE_RE.split(flat) if s.strip()]

    def _pack(self, sents: list[Sentence]) -> list[tuple[int, int, int]]:
        """Pack sentences into (start, end, tokens) spans honoring target/max/
        overlap; a single sentence is never split across two spans."""
        target = self.cfg["child_target_tokens"]
        hard_max = self.cfg["child_max_tokens"]
        overlap = self.cfg["overlap_tokens"]
        minimum = self.cfg["child_min_tokens"]

        spans: list[list[int]] = []
        i, n = 0, len(sents)
        while i < n:
            j, tokens = i, 0
            while j < n:
                t = sents[j].tokens
                if j > i and (tokens + t > target or tokens + t > hard_max):
                    break
                tokens += t
                j += 1
            spans.append([i, j, tokens])
            if j >= n:
                break
            if overlap > 0:                          # seed next span with trailing sentences
                k, otok = j, 0
                while k - 1 > i and otok + sents[k - 1].tokens <= overlap:
                    otok += sents[k - 1].tokens
                    k -= 1
                i = k
            else:
                i = j

        # merge a trailing fragment smaller than the minimum into its predecessor
        if len(spans) > 1 and spans[-1][2] < minimum:
            start = spans[-2][0]
            end = spans[-1][1]
            merged_tokens = sum(s.tokens for s in sents[start:end])
            if merged_tokens <= hard_max:
                spans[-2] = [start, end, merged_tokens]
                spans.pop()
        return [tuple(s) for s in spans]

    def _breadcrumb(self, doc_name: str, path_str: str, page: int, leaf: str | None = None) -> str:
        # skip the filename-derived doc name when the path already starts with
        # the document's H1 title, so the breadcrumb is not redundant
        redundant = path_str and self._doc_title and path_str.split(" > ")[0] == self._doc_title
        parts = ([] if redundant else [doc_name]) \
            + ([path_str] if path_str else []) + ([leaf] if leaf else [])
        return f"{' > '.join(parts)} (p.{page})"

    def _make_child(self, doc_id: str, doc_name: str, index: int, parent: dict,
                    kind: str, raw: str, page: int, tokens: int, leaf: str | None = None) -> dict:
        crumb = self._breadcrumb(doc_name, parent["section_path"], page, leaf)
        child = {
            "chunk_id": f"{doc_id}::c{index:04d}",
            "doc_id": doc_id,
            "kind": kind,
            "raw_text": raw,
            "embed_text": f"{crumb}\n{raw}" if self.cfg["breadcrumb_enabled"] else raw,
            "section_path": parent["section_path"],
            "page_id": page,
            "parent_id": parent["parent_id"],
            "token_count": tokens,
        }
        parent["children"].append(child["chunk_id"])
        return child

    def _build_children(self, parents: list[dict], doc_id: str, doc_name: str) -> list[dict]:
        children: list[dict] = []

        for parent in parents:
            prose: list[Block] = []

            def flush_prose():
                if not prose:
                    return
                sents = [s for b in prose for s in self._split_sentences(b)]
                for start, end, tokens in self._pack(sents):
                    raw = " ".join(s.text for s in sents[start:end])
                    children.append(self._make_child(
                        doc_id, doc_name, len(children), parent,
                        "text", raw, sents[start].page, tokens))
                prose.clear()

            for block in parent.pop("_blocks"):
                if block.kind == "text":
                    prose.append(block)
                else:                                # tables/figures are atomic children
                    flush_prose()
                    leaf = block.text.splitlines()[0].strip()
                    children.append(self._make_child(
                        doc_id, doc_name, len(children), parent,
                        block.kind, block.text, block.page,
                        self.counter.count(block.text), leaf=leaf))
            flush_prose()
        return children

    # ------------------------------------------------------------------
    # Per-file chunking and output
    # ------------------------------------------------------------------

    def chunk_file(self, path: Path) -> tuple[list[dict], list[dict]]:
        text = path.read_text(encoding="utf-8")
        doc_id = path.stem
        doc_name = doc_id.replace("_", " ")
        m = re.search(r"^# (.+?)\s*$", text, re.MULTILINE)
        self._doc_title = m.group(1).strip() if m else None
        blocks = self._parse_blocks(text)
        sections = self._group_sections(blocks)
        parents = self._build_parents(sections, doc_id)
        children = self._build_children(parents, doc_id, doc_name)
        return children, parents

    def _write_outputs(self, stem: str, children: list[dict], parents: list[dict], out_dir: Path):
        rule, thin = "=" * 80, "-" * 80

        lines = []
        for c in children:
            lines += [rule,
                      f"[{c['chunk_id']}] kind={c['kind']} | page={c['page_id']} | "
                      f"parent={c['parent_id']} | tokens={c['token_count']}",
                      f"section: {c['section_path'] or '(none)'}",
                      thin, c["raw_text"], ""]
        (out_dir / f"{stem}_chunks.txt").write_text("\n".join(lines), encoding="utf-8")

        fields = self.cfg.get("metadata_fields") or list(children[0].keys())
        meta = [{k: c[k] for k in fields if k in c} for c in children]
        (out_dir / f"{stem}_chunks_metadata.json").write_text(
            json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")

        lines = []
        for p in parents:
            lines += [rule,
                      f"[{p['parent_id']}] pages {p['page_start']}-{p['page_end']} | "
                      f"tokens={p['token_count']} | children: {', '.join(p['children']) or '(none)'}",
                      f"section: {p['section_path'] or '(none)'}",
                      thin, p["text"], ""]
        (out_dir / f"{stem}_parent_map.txt").write_text("\n".join(lines), encoding="utf-8")

    # ------------------------------------------------------------------
    # Entry point: chunk every file, embed once, build one FAISS index
    # ------------------------------------------------------------------

    def run(self) -> dict:
        data_dir = Path(self.cfg["data_dir"])
        out_dir = Path(self.cfg["output_dir"])
        out_dir.mkdir(parents=True, exist_ok=True)

        files = sorted(data_dir.glob("*.md"))
        if not files:
            raise FileNotFoundError(f"No .md files found in {data_dir.resolve()}")

        all_children: list[dict] = []
        all_parents: dict[str, dict] = {}
        for f in files:
            children, parents = self.chunk_file(f)
            self._write_outputs(f.stem, children, parents, out_dir)
            all_children.extend(children)
            for p in parents:
                all_parents[p["parent_id"]] = {k: p[k] for k in
                                               ("doc_id", "section_path", "text",
                                                "page_start", "page_end", "token_count", "children")}
            kinds = [c["kind"] for c in children]
            print(f"[chunker] {f.name}: {len(children)} children "
                  f"({kinds.count('text')} text, {kinds.count('table')} table, "
                  f"{kinds.count('figure')} figure), {len(parents)} parents")

        print(f"[chunker] embedding {len(all_children)} child chunks ...")
        vectors = self.client.embed([c["embed_text"] for c in all_children])
        faiss.normalize_L2(vectors)
        index = faiss.IndexFlatIP(vectors.shape[1])
        index.add(vectors)
        faiss.write_index(index, str(out_dir / self.cfg["faiss_index_file"]))

        store = {
            "embedding_model": self.cfg["embedding_model"],
            "dim": int(vectors.shape[1]),
            "chunks": all_children,        # position-aligned with the FAISS index
            "parents": all_parents,
        }
        (out_dir / self.cfg["faiss_store_file"]).write_text(
            json.dumps(store, indent=2, ensure_ascii=False), encoding="utf-8")
        print(f"[chunker] wrote {self.cfg['faiss_index_file']} "
              f"({index.ntotal} vectors, dim {vectors.shape[1]}) and {self.cfg['faiss_store_file']}")
        return store
