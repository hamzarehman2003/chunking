"""Component B: retrieval evaluation harness.

Generates per-page specific/broad questions with Mistral, embeds them with the
same GTE model and preprocessing as Component A, queries the FAISS index in
read-only mode and reports hit@k, MRR, mean/median rank and per-query latency
in one consolidated CSV.
"""
from __future__ import annotations

import csv
import json
import re
import statistics
import time
from pathlib import Path

import faiss

from chunker import StructureAwareChunker

JSON_BLOCK_RE = re.compile(r"\{.*\}", re.DOTALL)


class RetrievalEvaluator:
    def __init__(self, config: dict, counter, client):
        self.cfg = config["evaluation"]
        self.chunk_cfg = config["chunking"]
        self.counter = counter
        self.client = client
        self.page_re = StructureAwareChunker.compile_page_pattern(self.chunk_cfg["page_tag_pattern"])
        self.index = None
        self.chunks: list[dict] = []
        self.parents: dict[str, dict] = {}

    # ------------------------------------------------------------------
    # Index loading (strictly read-only: the index is never modified)
    # ------------------------------------------------------------------

    def load_store(self):
        out_dir = Path(self.chunk_cfg["output_dir"])
        index_path = out_dir / self.chunk_cfg["faiss_index_file"]
        store_path = out_dir / self.chunk_cfg["faiss_store_file"]
        if not index_path.exists() or not store_path.exists():
            raise FileNotFoundError(
                f"Missing {index_path.name} or {store_path.name} in {out_dir.resolve()} - run Component A first.")
        self.index = faiss.read_index(str(index_path))
        store = json.loads(store_path.read_text(encoding="utf-8"))
        self.chunks = store["chunks"]
        self.parents = store["parents"]
        if self.index.ntotal != len(self.chunks):
            raise RuntimeError(
                f"Index/metadata mismatch: {self.index.ntotal} vectors vs {len(self.chunks)} chunk records.")
        print(f"[evaluator] loaded index with {self.index.ntotal} vectors "
              f"and {len(self.parents)} parent sections (read-only)")

    # ------------------------------------------------------------------
    # Question generation
    # ------------------------------------------------------------------

    def _question_prompt(self, page_text: str) -> list[dict]:
        n_specific = self.cfg["questions_per_page_specific"]
        n_broad = self.cfg["questions_per_page_broad"]
        user = (
            f"Below is one page of a document. Generate up to {n_specific} SPECIFIC questions and "
            f"up to {n_broad} BROAD questions about it.\n"
            "- SPECIFIC: narrow, fact-level questions answerable from a single passage, table, or figure "
            "on this page. Include detail-oriented questions (numbers, names, figures).\n"
            "- BROAD: higher-level questions requiring synthesis of the page's content "
            "(main theme, conclusions, implications).\n"
            "- Mix factual, inferential, and detail-oriented styles. Every question must be answerable "
            "strictly from this page alone.\n"
            'Return ONLY valid JSON in the form {"specific": ["..."], "broad": ["..."]} '
            "with no other text.\n\n"
            f"PAGE TEXT:\n{page_text}"
        )
        return [
            {"role": "system", "content": "You generate high-quality retrieval-evaluation questions "
                                          "strictly grounded in the provided document page."},
            {"role": "user", "content": user},
        ]

    def _parse_questions(self, reply: str) -> dict:
        text = reply.strip()
        if text.startswith("```"):
            text = re.sub(r"^```[a-zA-Z]*\s*|\s*```$", "", text, flags=re.DOTALL)
        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            m = JSON_BLOCK_RE.search(text)
            if not m:
                return {"specific": [], "broad": []}
            try:
                data = json.loads(m.group(0))
            except json.JSONDecodeError:
                return {"specific": [], "broad": []}
        return {
            "specific": [q for q in data.get("specific", []) if isinstance(q, str)][
                : self.cfg["questions_per_page_specific"]],
            "broad": [q for q in data.get("broad", []) if isinstance(q, str)][
                : self.cfg["questions_per_page_broad"]],
        }

    def generate_questions(self, path: Path) -> list[dict]:
        text = path.read_text(encoding="utf-8")
        pages = StructureAwareChunker.parse_pages(text, self.page_re)
        questions: list[dict] = []
        for page_no, page_text in pages:
            if len(page_text) < self.cfg.get("min_page_chars", 200):
                continue
            try:
                reply = self.client.chat(self._question_prompt(page_text))
                parsed = self._parse_questions(reply)
            except Exception as exc:                      # keep evaluating remaining pages
                print(f"[evaluator] WARNING: question generation failed for "
                      f"{path.name} p.{page_no}: {exc}")
                continue
            for tier in ("specific", "broad"):
                for q in parsed[tier]:
                    questions.append({"doc_id": path.stem, "source_file": path.name,
                                      "page_no": page_no, "type": tier, "question": q})
        return questions

    # ------------------------------------------------------------------
    # Querying
    # ------------------------------------------------------------------

    def _search(self, question: str, doc_id: str) -> tuple[list[tuple[float, dict]], float]:
        """Embed + search (latency covers both); filter to the question's source
        document and keep the best-scoring child per parent section."""
        t0 = time.perf_counter()
        vec = self.client.embed([question])
        faiss.normalize_L2(vec)
        k = min(self.index.ntotal, max(self.cfg["top_K"] * 10, 100))
        scores, ids = self.index.search(vec, k)
        latency_ms = (time.perf_counter() - t0) * 1000.0

        results, seen_parents = [], set()
        for score, idx in zip(scores[0], ids[0]):
            if idx < 0:
                continue
            chunk = self.chunks[idx]
            if chunk["doc_id"] != doc_id or chunk["parent_id"] in seen_parents:
                continue
            seen_parents.add(chunk["parent_id"])
            results.append((float(score), chunk))
            if len(results) >= self.cfg["top_K"]:
                break
        return results, latency_ms

    # ------------------------------------------------------------------
    # Evaluation loop
    # ------------------------------------------------------------------

    def run(self) -> dict:
        self.load_store()
        data_dir = Path(self.chunk_cfg["data_dir"])
        out_dir = Path(self.chunk_cfg["output_dir"])
        threshold = self.cfg["similarity_threshold"]
        tolerance = self.cfg["neighbour_page_tolerance"]
        k_values = self.cfg["hit_k_values"]
        max_chars = self.cfg.get("retrieved_text_max_chars", 1000)

        rows: list[dict] = []
        for f in sorted(data_dir.glob("*.md")):
            questions = self.generate_questions(f)
            print(f"[evaluator] {f.name}: {len(questions)} questions generated")
            for q in questions:
                results, latency_ms = self._search(q["question"], q["doc_id"])

                rank = None
                for pos, (score, chunk) in enumerate(results, start=1):
                    if score < threshold or chunk["page_id"] is None:
                        continue
                    if abs(chunk["page_id"] - q["page_no"]) <= tolerance:
                        rank = pos
                        break

                top_score, top_chunk = results[0] if results else (None, None)
                parent_text = (self.parents[top_chunk["parent_id"]]["text"]
                               if top_chunk else "")
                row = {
                    "source_file_name": q["source_file"],
                    "question_type": q["type"],
                    "question": q["question"],
                    "retrieved_chunk": parent_text[:max_chars],
                    "question_page_no": q["page_no"],
                    "retrieved_chunk_page_no": top_chunk["page_id"] if top_chunk else "",
                    "similarity_score": round(top_score, 4) if top_score is not None else "",
                    "rank": rank if rank else "",
                    "reciprocal_rank": round(1.0 / rank, 4) if rank else 0.0,
                    "latency_ms": round(latency_ms, 2),
                }
                for k in k_values:
                    row[f"hit@{k}"] = int(rank is not None and rank <= k)
                rows.append(row)

        if not rows:
            raise RuntimeError("No questions were generated - nothing to evaluate.")

        csv_path = out_dir / self.cfg["results_csv"]
        with open(csv_path, "w", newline="", encoding="utf-8") as fh:
            writer = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)

        summary = self._summarize(rows, k_values)
        (out_dir / self.cfg.get("summary_json", "evaluation_summary.json")).write_text(
            json.dumps(summary, indent=2), encoding="utf-8")
        self._print_summary(summary)
        print(f"[evaluator] wrote {csv_path}")
        return summary

    @staticmethod
    def _summarize(rows: list[dict], k_values: list[int]) -> dict:
        n = len(rows)
        ranks = [r["rank"] for r in rows if r["rank"]]
        latencies = [r["latency_ms"] for r in rows]
        by_type: dict[str, int] = {}
        for r in rows:
            by_type[r["question_type"]] = by_type.get(r["question_type"], 0) + 1
        return {
            "questions_total": n,
            "questions_by_type": by_type,
            "hit_at_k": {f"hit@{k}": round(sum(r[f"hit@{k}"] for r in rows) / n, 4) for k in k_values},
            "mrr": round(sum(r["reciprocal_rank"] for r in rows) / n, 4),
            "mean_rank_of_hits": round(statistics.mean(ranks), 2) if ranks else None,
            "median_rank_of_hits": statistics.median(ranks) if ranks else None,
            "questions_without_hit": n - len(ranks),
            "mean_latency_ms": round(statistics.mean(latencies), 2),
            "median_latency_ms": round(statistics.median(latencies), 2),
        }

    @staticmethod
    def _print_summary(s: dict):
        print("\n=== Retrieval Evaluation Summary ===")
        print(f"questions: {s['questions_total']} {s['questions_by_type']}")
        for name, value in s["hit_at_k"].items():
            print(f"{name:>8}: {value:.4f}")
        print(f"     MRR: {s['mrr']:.4f}")
        print(f"mean rank (hits): {s['mean_rank_of_hits']}  |  "
              f"median rank (hits): {s['median_rank_of_hits']}  |  "
              f"no-hit questions: {s['questions_without_hit']}")
        print(f"latency ms: mean {s['mean_latency_ms']} / median {s['median_latency_ms']}")
