# Structure-Aware Chunking & Retrieval Evaluation

Two components, driven entirely by `config.json`:

- **Component A** (`chunker.py`, class `StructureAwareChunker`) — parses extractor
  Markdown (page tags, heading hierarchy, `### Table-x.x` / `### Figure-x.x` blocks)
  into large **parent sections** and small sentence-packed **child chunks**
  ("small-to-big"). Children get a contextual breadcrumb
  (`Document > Section > Subsection (p.N)`) prepended before embedding, are embedded
  with GTE via the Stellar endpoint, and stored in a single FAISS index
  (cosine similarity via inner product over L2-normalized vectors) covering all
  input documents.
- **Component B** (`evaluator.py`, class `RetrievalEvaluator`) — for each page of each
  source document, generates up to 3 *specific* + 3 *broad* questions with Mistral,
  embeds them identically to Component A, queries the FAISS index **read-only**
  (restricted to the question's source document), and reports hit@{1,3,5,10}, MRR,
  mean/median rank, and per-query latency (embedding + search combined).

Shared infrastructure (config loader, gpt2 `TokenCounter`, R2D2 OAuth, Stellar client,
offline mock client) lives in `models.py`.

## Setup

```bash
pip install -r requirements.txt
copy .env.example .env     # then fill in the credential values
```

`gpt2_tokenizer/gpt2_tokenizer.json` must be present (it is used for all token counts).

## Run

```bash
python main.py chunk          # Component A only
python main.py evaluate       # Component B only (requires Component A outputs)
python main.py all            # both
python main.py all --mock    # offline end-to-end validation (no credentials needed)
```

Mock mode substitutes hashed lexical embeddings and template-generated questions —
it validates the pipeline mechanics and output formats, **not** semantic retrieval
quality.

## Outputs (`output/`)

Per input file `<name>.md`:

| file | content |
|---|---|
| `<name>_chunks.txt` | human-readable child chunks |
| `<name>_chunks_metadata.json` | child metadata (fields configurable via `chunking.metadata_fields`) |
| `<name>_parent_map.txt` | parent sections with their child-chunk IDs |

Consolidated across all input files:

| file | content |
|---|---|
| `faiss_index.bin` | single FAISS index (all child embeddings) |
| `faiss_store.json` | position-aligned chunk metadata + parent map (read by Component B) |
| `evaluation_results.csv` | one row per question: source_file_name, question_type, question, retrieved_chunk, question_page_no, retrieved_chunk_page_no, similarity_score, hit@k, rank, reciprocal_rank, latency_ms |
| `evaluation_summary.json` | overall hit@k, MRR, mean/median rank, latency stats |

## Design decisions

- **Score dilution vs. fragmentation** — children (~320 tokens, max 512, sentence-level
  overlap ~48 tokens) concentrate the relevance signal; a child hit returns its full
  parent section (max 3500 tokens, paragraphs never split across parents) as the answer
  context.
- **Atomic units** — tables, figures, and single sentences are never split. Table/figure
  children carry their own breadcrumb leaf (e.g. `... > Table-3.1 (p.3)`).
- **Fragment merging** — a trailing prose fragment under `child_min_tokens` (64) merges
  into the preceding child (skipped only if the merge would exceed the 512 hard max).
- **Page tags** — `### Page: {n}` lines are removed from all chunk text but the page
  number is tracked in metadata for every child and parent.
- **Sectionless documents** — with no headings, consecutive paragraphs are combined
  under the same token limits (empty section path).
- **Hits** — a question hits when the retrieved child's `page_id` is within
  `neighbour_page_tolerance` (1) of the question's page and its similarity is at or
  above `similarity_threshold`. Ranked results are deduplicated by parent (best child
  per parent) so top-k slots are not wasted on the same section.
- **Read-only evaluation** — Component B only ever calls `faiss.read_index` and search;
  it never adds to or writes the index.
- **No embedding-breakpoint "semantic chunking"** — splitting is purely structural
  (headings/pages/paragraphs/sentences + token budgets).

## Credentials

Real (non-mock) runs need these environment variables (see `.env.example`):
`R2D2__TOKEN_URL`, `R2D2__SCOPE`, `R2D2__GRANT_TYPE`, `R2D2__CLIENT_ID`,
`R2D2__CLIENT_SECRET`, `SSL_CERT_FILE`, `REQUESTS__CA_BUNDLE`
(plus optional `R2D2__VERTEX_PROJECT`, `R2D2__HOST`), and network access to the
Stellar endpoint configured in `config.json`.
