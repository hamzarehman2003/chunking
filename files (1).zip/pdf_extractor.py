"""
pdf_extractor.py
Structure-preserving PDF -> Markdown extraction for downstream
section-aware chunking and LLM consumption.

Engine: PyMuPDF (fitz) - fastest Python PDF library (C core), with native
table detection, image extraction, links, and font metadata in one pass.
"""

from __future__ import annotations

import hashlib
import logging
import re
from collections import Counter
from pathlib import Path

import fitz  # PyMuPDF

log = logging.getLogger("pdf_extractor")

BULLET_CHARS = "•◦▪‣·-–—*"
_BULLET_RE = re.compile(rf"^\s*[{re.escape(BULLET_CHARS)}]\s+")
_NUMLIST_RE = re.compile(r"^\s*(\d{1,3}[.)]|[a-zA-Z][.)]|[ivxIVX]+[.)])\s+")
_MONO_HINT = re.compile(r"(mono|courier|consol|menlo|code)", re.I)
_BOLD_FLAG = 2 ** 4  # fitz span flag bit for bold


class PDFExtractor:
    """Extracts a PDF into clean, hierarchy-aware Markdown.

    Pipeline per page:
      1. Detect tables -> Markdown, remember their bboxes.
      2. Collect image blocks (with bboxes), save files, emit placeholders.
      3. Collect text blocks outside table bboxes, tag headings/lists/code.
      4. Merge all elements in reading order (column-aware sort).
    Document-level passes: body-font calibration, repeating header/footer
    removal, hyperlink injection, metadata front matter.
    """

    def __init__(self, config: dict):
        self.cfg = config
        self.out_dir = Path(config["paths"]["output_dir"])
        self.img_dir = self.out_dir / config["paths"]["image_subdir"]
        self._seen_hashes: set[str] = set()
        self._heading_sizes: list[float] = []
        self._body_size: float = 0.0

    # ------------------------------------------------------------------ #
    # public API
    # ------------------------------------------------------------------ #
    def extract(self, pdf_path: str | Path) -> Path:
        """Run full extraction; returns path of the written .md file."""
        pdf_path = Path(pdf_path)
        self.out_dir.mkdir(parents=True, exist_ok=True)
        if self.cfg["images"]["enabled"]:
            self.img_dir.mkdir(parents=True, exist_ok=True)

        doc = fitz.open(pdf_path)
        self._calibrate_fonts(doc)
        furniture = self._find_repeating_furniture(doc)

        parts: list[str] = []
        if self.cfg["content"]["extract_metadata"]:
            parts.append(self._front_matter(doc, pdf_path))

        for page in doc:
            parts.append(self._render_page(page, furniture))

        md = "\n\n".join(p for p in parts if p.strip())
        if self.cfg["content"]["normalize_whitespace"]:
            md = re.sub(r"\n{3,}", "\n\n", md).strip() + "\n"

        out_file = self.out_dir / f"{pdf_path.stem}.md"
        out_file.write_text(md, encoding="utf-8")
        doc.close()
        log.info("Wrote %s", out_file)
        return out_file

    # ------------------------------------------------------------------ #
    # document-level analysis
    # ------------------------------------------------------------------ #
    def _calibrate_fonts(self, doc: fitz.Document) -> None:
        """Find the body font size (mode) and the distinct larger sizes
        used as heading tiers across the whole document."""
        sizes: Counter = Counter()
        for page in doc:
            for block in page.get_text("dict", flags=fitz.TEXTFLAGS_TEXT)["blocks"]:
                for line in block.get("lines", []):
                    for span in line["spans"]:
                        if span["text"].strip():
                            sizes[round(span["size"], 1)] += len(span["text"])
        if not sizes:
            return
        self._body_size = sizes.most_common(1)[0][0]
        ratio = self.cfg["headings"]["min_size_ratio"]
        bigger = sorted(
            (s for s in sizes if s >= self._body_size * ratio), reverse=True
        )
        self._heading_sizes = bigger[: self.cfg["headings"]["max_levels"]]

    def _find_repeating_furniture(self, doc: fitz.Document) -> set[str]:
        """Text lines that repeat in the top/bottom page margins across
        many pages (running headers, footers, page numbers)."""
        lay = self.cfg["layout"]
        if not lay["strip_headers_footers"] or len(doc) < 2:
            return set()
        counts: Counter = Counter()
        for page in doc:
            h = page.rect.height
            top, bot = h * lay["header_margin_pct"], h * (1 - lay["footer_margin_pct"])
            for block in page.get_text("dict", flags=fitz.TEXTFLAGS_TEXT)["blocks"]:
                y0, y1 = block["bbox"][1], block["bbox"][3]
                if y1 <= top or y0 >= bot:
                    text = self._block_text(block)
                    key = re.sub(r"\d+", "#", text.strip())  # "Page 3" == "Page 7"
                    if key:
                        counts[key] += 1
        thresh = len(doc) * lay["repeat_threshold"]
        return {k for k, c in counts.items() if c > thresh}

    def _front_matter(self, doc: fitz.Document, pdf_path: Path) -> str:
        m = doc.metadata or {}
        rows = {
            "title": m.get("title") or pdf_path.stem,
            "author": m.get("author"),
            "subject": m.get("subject"),
            "created": m.get("creationDate"),
            "modified": m.get("modDate"),
            "pages": doc.page_count,
            "source": pdf_path.name,
        }
        lines = [f"{k}: {v}" for k, v in rows.items() if v]
        return "---\n" + "\n".join(lines) + "\n---"

    # ------------------------------------------------------------------ #
    # page rendering
    # ------------------------------------------------------------------ #
    def _render_page(self, page: fitz.Page, furniture: set[str]) -> str:
        elements: list[tuple[fitz.Rect, str]] = []  # (bbox, markdown)
        table_rects: list[fitz.Rect] = []

        # -- tables -----------------------------------------------------
        if self.cfg["tables"]["enabled"]:
            finder = page.find_tables(strategy=self.cfg["tables"]["strategy"])
            for t_num, table in enumerate(finder.tables, 1):
                rect = fitz.Rect(table.bbox)
                table_rects.append(rect)
                md = self._table_to_md(table)
                heading = f"## Table-{page.number + 1}.{t_num}"
                elements.append((rect, f"{heading}\n\n{md}"))

        # -- links (bbox -> uri) ----------------------------------------
        links = (
            [(fitz.Rect(l["from"]), l["uri"]) for l in page.get_links() if l.get("uri")]
            if self.cfg["content"]["extract_links"]
            else []
        )

        # -- text & image blocks ----------------------------------------
        img_num = 0
        for block in page.get_text("dict")["blocks"]:
            rect = fitz.Rect(block["bbox"])
            if block["type"] == 1:  # image
                if not self.cfg["images"]["enabled"]:
                    continue
                img_num += 1
                placeholder = self._save_image(block, page.number + 1, img_num)
                if placeholder:
                    elements.append((rect, placeholder))
                else:
                    img_num -= 1  # skipped (too small / duplicate)
                continue
            if any(rect in tr or rect.intersects(tr) for tr in table_rects):
                continue  # text already captured inside a table
            md = self._block_to_md(block, furniture, links)
            if md:
                elements.append((rect, md))

        # -- reading order ----------------------------------------------
        elements.sort(key=self._reading_key(page))
        mds = [md for _, md in elements]
        merged: list[str] = []
        for md in mds:  # PDFs often emit the bullet glyph as its own block
            if merged and merged[-1].strip() in set(BULLET_CHARS) and "\n" not in md:
                merged[-1] = "- " + md.strip()
            else:
                merged.append(md)
        body = "\n\n".join(merged)

        if self.cfg["content"]["page_breaks"]:
            body = f"<!-- page: {page.number + 1} -->\n\n{body}"
        return body

    def _reading_key(self, page: fitz.Page):
        """Column-aware sort: assign blocks to a column band, then sort
        by (column, y, x). Falls back to plain (y, x) if disabled."""
        if not self.cfg["layout"]["multi_column"]:
            return lambda el: (el[0].y0, el[0].x0)
        mid = page.rect.width / 2

        def key(el):
            r = el[0]
            spans_full = r.width > page.rect.width * 0.6
            col = 0 if spans_full or r.x0 < mid else 1
            # full-width elements order purely by y within column 0 stream
            return (0 if spans_full else col, round(r.y0, 1), r.x0) if not spans_full \
                else (0, round(r.y0, 1), -1)
        return key

    # ------------------------------------------------------------------ #
    # element converters
    # ------------------------------------------------------------------ #
    def _table_to_md(self, table) -> str:
        rows = table.extract()
        if not rows:
            return ""
        clean = [[(c or "").replace("\n", " ").strip() for c in row] for row in rows]
        width = max(len(r) for r in clean)
        clean = [r + [""] * (width - len(r)) for r in clean]
        header, *body = clean
        if not any(header):  # headerless table -> synthetic header
            header = [f"Col {i + 1}" for i in range(width)]
            body = clean
        out = ["| " + " | ".join(header) + " |",
               "| " + " | ".join(["---"] * width) + " |"]
        out += ["| " + " | ".join(r) + " |" for r in body]
        return "\n".join(out)

    def _save_image(self, block: dict, page_no: int, img_num: int) -> str | None:
        icfg = self.cfg["images"]
        w, h = block.get("width", 0), block.get("height", 0)
        if w < icfg["min_width"] or h < icfg["min_height"]:
            return None
        data: bytes = block["image"]
        if icfg["deduplicate"]:
            digest = hashlib.md5(data).hexdigest()
            if digest in self._seen_hashes:
                return None
            self._seen_hashes.add(digest)
        ext = icfg["format"]
        name = f"figure-{page_no}.{img_num}.{ext}"
        path = self.img_dir / name
        if block.get("ext", "png") == ext:
            path.write_bytes(data)
        else:  # convert via Pixmap
            pix = fitz.Pixmap(data)
            if pix.alpha and ext == "jpg":
                pix = fitz.Pixmap(fitz.csRGB, pix)
            pix.save(path)
        rel = f"{self.img_dir.name}/{name}"
        return f"## Figure-{page_no}.{img_num}\n\n![Figure {page_no}.{img_num}]({rel})"

    def _block_to_md(self, block: dict, furniture: set[str],
                     links: list[tuple[fitz.Rect, str]]) -> str:
        """Classify each LINE (heading / list / code / body), then group
        consecutive lines of the same class. Line-level handling prevents a
        heading merged into a neighbouring block from being lost."""
        raw = self._block_text(block)
        if not raw.strip():
            return ""
        if re.sub(r"\d+", "#", raw.strip()) in furniture:
            return ""  # running header / footer / page number

        classified: list[tuple[str, str]] = []  # (class, text)
        for line in block.get("lines", []):
            spans = [s for s in line["spans"] if s["text"].strip()]
            if not spans:
                continue
            text = self._line_text(line, links)
            lvl = self._heading_level(spans, text)
            if lvl:  # heading beats list: "1. Introduction" at H1 size
                cls = f"h{lvl}"
            elif self.cfg["content"]["detect_lists"] and (
                    _BULLET_RE.match(text) or _NUMLIST_RE.match(text)):
                cls = "list"
            elif self.cfg["content"]["detect_code"] and all(
                    _MONO_HINT.search(s["font"]) for s in spans):
                cls = "code"
            else:
                cls = "body"
            classified.append((cls, text))

        out, i = [], 0
        while i < len(classified):
            cls = classified[i][0]
            group = []
            while i < len(classified) and classified[i][0] == cls:
                group.append(classified[i][1])
                i += 1
            if cls.startswith("h"):
                out += [f"{'#' * int(cls[1:])} {' '.join(t.split())}" for t in group]
            elif cls == "code":
                out.append("```\n" + "\n".join(group) + "\n```")
            elif cls == "list":
                out.append("\n".join(
                    "- " + _BULLET_RE.sub("", t).strip() if _BULLET_RE.match(t)
                    else t.strip() for t in group))
            else:  # body paragraph: join wrapped lines, de-hyphenate
                para = ""
                for t in group:
                    para = para[:-1] + t if para.endswith("-") else (para + " " + t if para else t)
                if self.cfg["content"]["normalize_whitespace"]:
                    para = re.sub(r"\s{2,}", " ", para).strip()
                if self.cfg["content"]["detect_lists"] and _BULLET_RE.match(para):
                    para = "- " + _BULLET_RE.sub("", para).strip()
                out.append(para)
        return "\n\n".join(out)

    # ------------------------------------------------------------------ #
    # low-level helpers
    # ------------------------------------------------------------------ #
    def _line_text(self, line: dict, links: list[tuple[fitz.Rect, str]]) -> str:
        """Assemble a line, wrapping contiguous span runs that sit inside a
        link annotation (>=50%% bbox overlap) as one [text](url)."""
        parts, run, run_uri = [], [], None

        def flush():
            nonlocal run, run_uri
            if run:
                text = "".join(run)
                parts.append(f"[{text.strip()}]({run_uri})" if run_uri else text)
            run, run_uri = [], None

        for span in line["spans"]:
            uri = None
            r = fitz.Rect(span["bbox"])
            if links and span["text"].strip() and not r.is_empty:
                for lr, u in links:
                    inter = fitz.Rect(r) & lr
                    if not inter.is_empty and inter.get_area() >= 0.5 * r.get_area():
                        uri = u
                        break
            if uri != run_uri:
                flush()
                run_uri = uri
            run.append(span["text"])
        flush()
        return "".join(parts).rstrip()

    @staticmethod
    def _block_text(block: dict) -> str:
        return "\n".join(
            "".join(s["text"] for s in line["spans"]).rstrip()
            for line in block.get("lines", []))

    def _heading_level(self, spans: list[dict], text: str) -> int:
        if not self.cfg["headings"]["detect"] or not self._heading_sizes:
            return 0
        if len(text) > 120 or _BULLET_RE.match(text) or not re.search(r"[A-Za-z0-9]", text):
            return 0  # long lines, bullets, bare glyphs are never headings
        size = max(s["size"] for s in spans)
        for i, hs in enumerate(self._heading_sizes):
            if abs(size - hs) < 0.5:
                return i + 1
        if (self.cfg["headings"]["bold_body_is_heading"]
                and all(s["flags"] & _BOLD_FLAG for s in spans)
                and abs(size - self._body_size) < 0.5):
            return min(len(self._heading_sizes) + 1, 6)
        return 0
