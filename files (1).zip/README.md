# PDF → Structured Markdown Extractor

Structure-preserving PDF extraction optimized for downstream **section-aware
chunking** and LLM retrieval. Single class (`PDFExtractor`), simple driver,
all parameters in `config.yaml`.

## Why PyMuPDF

| Requirement | PyMuPDF (fitz) |
|---|---|
| Speed | C core (MuPDF); ~40 pages/sec on this pipeline, no GPU, fully on-prem |
| Tables | Native `page.find_tables()` with bbox → tables re-inserted in place |
| Images | Image blocks carry bbox + raw bytes → placeholder at original location |
| Structure | Per-span font size/flags/font name → heading, bold, monospace inference |
| Links / metadata | `page.get_links()`, `doc.metadata` in the same pass |

Alternatives considered: `pdfplumber` (good tables, slow, no images-with-position),
`pymupdf4llm` (fast Markdown but no control over placeholder format or
header/footer stripping), VLM OCR (Granite-Docling / Mistral OCR — better for
*scanned* documents but orders of magnitude slower; this pipeline targets
born-digital PDFs). For scanned inputs, add an OCR pre-pass and keep this
pipeline unchanged.

## Usage

```bash
pip install -r requirements.txt
python main.py document.pdf            # or set paths.input_pdf in config.yaml
python main.py document.pdf -c my.yaml
```

Output:
```
output/
├── document.md
└── images/
    └── figure-{page}.{n}.png
```

## What the output guarantees (for chunking)

- **Hierarchy**: document-wide font calibration maps sizes → `#`–`####`
  headings, so a header-based splitter (e.g. `MarkdownHeaderTextSplitter`)
  gets real sections.
- **Tables in place** under `## Table-{page}.{n}` — atomic, never split
  mid-table by a chunker keying on headings.
- **Figures in place** as `## Figure-{page}.{n}` + image link; captions stay
  adjacent for contextual retrieval.
- **Reading order**: column-aware bbox sort handles two-column layouts.
- **No noise**: repeating headers/footers/page numbers detected across pages
  (digits normalized, so "Page 3" ≡ "Page 7") and stripped.
- **Paragraph integrity**: wrapped lines re-joined, end-of-line hyphenation
  repaired, lists normalized to `- ` items, monospace blocks fenced.
- **Chunking anchors**: `<!-- page: N -->` comments give page provenance for
  citations without polluting rendered Markdown.
- **Front matter**: title/author/dates/pages as YAML — usable as chunk
  metadata.
- **Hyperlinks** preserved inline as `[text](url)`.

## Key config knobs

- `tables.strategy`: `lines_strict` (ruled tables, default) → `text` for
  borderless tables.
- `headings.min_size_ratio`: lower it if headings in your corpus are barely
  larger than body text; enable `bold_body_is_heading` for bold-only headings.
- `layout.repeat_threshold` / margin percentages: tune furniture removal.
- `images.deduplicate`: drops repeated logos/watermarks automatically.
