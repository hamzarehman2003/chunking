### Page: 1

This overview document was prepared for the municipal infrastructure committee ahead of the January capital planning session. It summarizes the condition of the Greenfield Basin wastewater treatment plant, the regulatory drivers requiring an upgrade before 2029, and the three upgrade pathways evaluated by the engineering consultant. Readers seeking the full 400-page technical appendix should consult the project document repository; this overview deliberately restricts itself to material relevant to the committee's funding decision.

The Greenfield Basin plant serves 182,000 residents and roughly 300 industrial and commercial dischargers. It was commissioned in 1987 with a design capacity of 45 megaliters per day and currently receives an average dry-weather flow of 51 megaliters per day, meaning the plant operates 13 percent above its design basis. Wet-weather peaks have exceeded 140 megaliters per day on eleven occasions in the past three years, forcing partially treated discharges that triggered four notices of violation from the environmental regulator.

# Greenfield Basin Wastewater Treatment Plant Upgrade Overview

## Current Plant Condition

### Page: 2

### Process Performance

The plant uses a conventional activated sludge process with primary clarification, fine-bubble aeration, secondary clarification, and chlorine disinfection. Effluent quality currently averages 22 milligrams per liter biochemical oxygen demand and 25 milligrams per liter total suspended solids, which meets the existing permit but exceeds the incoming 2029 permit limits of 10 and 12 milligrams per liter respectively. Ammonia removal is marginal: summer nitrification achieves 4 milligrams per liter effluent ammonia, but cold-weather performance degrades to 11 milligrams per liter because the aeration basins lack the solids retention time required for reliable winter nitrification at current loading.

Phosphorus is not currently removed by design; effluent total phosphorus averages 4.8 milligrams per liter against a future limit of 0.5. Meeting the phosphorus limit is the single most consequential driver of upgrade cost, since it requires either chemical dosing with ferric chloride and additional sludge handling, or a biological phosphorus removal configuration with anaerobic selector zones. The consultant's bench-scale testing on Greenfield mixed liquor showed reliable biological phosphorus removal is achievable, but it consumes primary clarifier capacity that is already constrained.

### Asset Condition

A condition assessment scored 412 discrete assets across the site using a five-point scale. Thirty-one percent of assets scored 4 or 5, meaning replacement is required within five years regardless of the process upgrade chosen. The most critical items are the three primary clarifier drive mechanisms, all original 1987 equipment with severe corrosion of the rake arms; the motor control center in the aeration blower building, which failed insulation-resistance testing; and the chlorine contact basin, where concrete spalling has exposed reinforcement over 15 percent of the wall area. The digester complex is in better condition following the 2016 rehabilitation, though digester gas piping requires replacement of all condensate traps.

### Page: 3

## Upgrade Pathways Evaluated

### Pathway Comparison

Three pathways were carried through concept design. Pathway A extends the existing activated sludge process with new aeration basins, a fifth secondary clarifier, ferric chloride dosing for phosphorus, and ultraviolet disinfection replacing chlorine. Pathway B converts the plant to a four-stage Bardenpho biological nutrient removal configuration within a mix of new and re-purposed basins, achieving both nitrogen and phosphorus limits biologically with reduced chemical consumption. Pathway C replaces the secondary process entirely with a membrane bioreactor, which delivers the highest effluent quality and the smallest footprint but carries the highest energy and membrane replacement costs.

### Table-3.1: Pathway comparison summary

| Criterion | Pathway A: AS Extension | Pathway B: Bardenpho BNR | Pathway C: Membrane bioreactor |
|---|---|---|---|
| Capital cost (million USD) | 118 | 134 | 171 |
| Annual O&M (million USD) | 6.2 | 5.1 | 8.9 |
| 2029 permit compliance | Marginal on phosphorus | Full | Full |
| Footprint | Largest | Moderate | Smallest |
| Energy use (kWh/ML) | 410 | 385 | 640 |
| Wet-weather capacity (ML/d) | 150 | 165 | 120 without auxiliary train |

As Table-3.1 shows, Pathway B achieves full compliance at a capital cost 13.6 percent above Pathway A while reducing annual operating cost by 1.1 million USD, primarily through lower chemical and sludge disposal costs. Pathway C's membrane bioreactor was assessed as poorly matched to Greenfield's wet-weather profile: membranes limit peak hydraulic throughput, so Pathway C requires an auxiliary wet-weather treatment train that erodes its footprint advantage and adds 14 million USD that is excluded from the capital figure shown in the table.

### Figure-3.2: Projected effluent phosphorus by pathway

The figure plots projected monthly effluent total phosphorus for each pathway over a simulated five-year horizon using the calibrated process model. Pathway A oscillates seasonally between 0.4 and 0.7 milligrams per liter, breaching the 0.5 limit in an estimated 14 percent of months, concentrated in winter when ferric dosing efficiency drops. Pathway B holds between 0.2 and 0.4 milligrams per liter year-round with a single modelled exceedance in the five years, associated with a simulated digester supernatant return spike. Pathway C remains below 0.1 milligrams per liter throughout, reflecting the membrane barrier's complete solids capture. The shaded band on the figure represents the 95 percent confidence interval from 500 Monte Carlo runs of influent variability.

### Page: 4

## Financial and Implementation Considerations

### Funding Strategy

The recommended funding package combines a state revolving fund loan of 95 million USD at 2.4 percent over 30 years, a state nutrient reduction grant of 22 million USD contingent on selecting a biological nutrient removal pathway, and rate revenue bonds for the balance. The nutrient grant is a decisive factor: it applies to Pathway B but not Pathway A, narrowing the effective capital gap between them to under 6 million USD. Rate modelling indicates a required average residential bill increase of 11 percent phased over four years for Pathway B, compared with 9 percent for Pathway A and 19 percent for Pathway C. The committee should note that the state revolving fund application window closes in September, and a complete facilities plan must accompany the application.

### Implementation Sequencing

Pathway B construction is sequenced to maintain full treatment throughout: the new anaerobic and anoxic zones are built on the decommissioned sludge lagoon footprint first, flows are then diverted basin by basin, and the existing aeration basins are retrofitted with fine-bubble diffusers and internal recycle pumping in three stages over 26 months. The critical-path item is the 132-week lead time quoted for the main switchgear replacement, which must be ordered within 90 days of funding approval to hold the overall 2029 compliance date. Early procurement packages for the switchgear and the secondary clarifier mechanisms are therefore recommended for committee approval alongside the main funding motion, at a combined value of 9.7 million USD.

The consultant recommends Pathway B, the four-stage Bardenpho configuration, as the preferred alternative. It is the only pathway that achieves full 2029 permit compliance while lowering annual operating cost, it preserves the plant's wet-weather capacity, and it qualifies for the state nutrient reduction grant. The committee is asked to endorse Pathway B, approve the two early procurement packages, and direct staff to submit the state revolving fund application before the September deadline.
