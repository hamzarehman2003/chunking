# Solar Microgrid Feasibility Study for Rural Electrification

### Page: 1

## Executive Summary

This feasibility study evaluates the deployment of solar photovoltaic microgrids across twelve rural districts in the coastal region. The study was commissioned by the Regional Energy Authority in March 2024 and concluded in November 2024. Field teams surveyed 4,850 households across the target districts, measuring baseline electricity access, willingness to pay, and projected demand growth over a ten-year horizon. The headline finding is that nine of the twelve districts can support financially sustainable microgrids at a levelized cost of electricity between 0.18 and 0.24 USD per kilowatt-hour, assuming a 20 percent capital subsidy from the national rural electrification fund.

The study further finds that anchor loads are the decisive factor in microgrid viability. Districts with agro-processing facilities, cold storage depots, or telecommunications towers achieved projected capacity utilization above 45 percent, whereas purely residential districts averaged only 28 percent. Battery storage sizing emerged as the single largest cost driver, accounting for 38 percent of total capital expenditure on average. The recommended configuration pairs lithium iron phosphate battery banks with a diesel backup generator limited to 5 percent of annual energy delivery, which keeps lifecycle emissions 82 percent below the diesel-only baseline while maintaining 99.2 percent service availability.

Three districts were assessed as not currently viable: Kelmara, Tovin Flats, and Upper Reswick. Their combined population density falls below 40 households per square kilometer, and grid extension from the existing 33 kV line is projected to be cheaper than a standalone microgrid by 2029. The study recommends deferring these districts to the national grid densification program and reallocating their subsidy envelope to the nine viable districts, which would raise the average equity internal rate of return from 11.4 percent to 13.1 percent.

### Page: 2

## Demand Assessment

### Household Survey Methodology

The demand assessment relied on a stratified random sample drawn from census enumeration areas, with strata defined by distance to the nearest all-weather road and by principal livelihood category. Enumerators administered a 45-minute structured questionnaire covering current energy expenditure, appliance ownership, business activities, and stated willingness to pay for three service tiers. To correct for stated-preference bias, the survey team ran revealed-preference pilots in two districts, installing prepaid meters in 120 volunteer households for a 90-day observation window. Observed consumption in the pilot came in 22 percent below stated intentions, and this correction factor was applied uniformly to the demand projections for all districts.

Household energy expenditure at baseline averaged 14.60 USD per month, dominated by kerosene for lighting, disposable dry-cell batteries, diesel for occasional generator rental, and mobile phone charging fees paid to kiosk operators. The survey found that 68 percent of households already own at least one mobile phone, 31 percent own a radio, and 9 percent own a television powered by car batteries recharged in the nearest market town. These figures indicate substantial latent demand for basic electricity services, and they anchor the Tier 1 service design of two light points and phone charging at 5.80 USD per month.

### Table-2.1: Projected demand by service tier

| Service tier | Monthly kWh | Target share of connections | Monthly tariff (USD) | Typical appliances |
|---|---|---|---|---|
| Tier 1: Basic | 4 | 55% | 5.80 | Two LED lights, phone charging |
| Tier 2: Standard | 18 | 30% | 12.40 | Lights, TV, fan, radio |
| Tier 3: Productive | 85 | 12% | 41.00 | Refrigeration, small machinery |
| Tier 4: Anchor | 420 | 3% | 160.00 | Agro-processing, cold storage, telecom |

The tier structure shown in Table-2.1 was validated against consumption data from fourteen operating microgrids in comparable regions. Tier migration is a critical revenue assumption: the financial model assumes 6 percent of Tier 1 customers upgrade to Tier 2 each year, consistent with the 5 to 8 percent range observed elsewhere. If tier migration stalls at 3 percent, the average project equity return falls by 2.7 percentage points, which underlines the importance of pairing electrification with appliance financing programs.

### Page: 3

## Technical Design

### Generation and Storage Sizing

The reference design for a mid-sized district pairs a 240 kWp solar array with a 520 kWh usable lithium iron phosphate battery bank and a 60 kVA diesel backup generator. The solar array is oversized relative to average daytime load by a factor of 1.6 to ensure the battery bank reaches full charge on 92 percent of days, based on 22 years of satellite irradiance data showing a mean global horizontal irradiance of 5.4 kWh per square meter per day with a wet-season trough of 4.1. Inverter capacity is set at 150 kVA, sized to the evening peak rather than to array output, since the two never coincide.

Battery autonomy is designed at 14 hours of mean load, which covers the evening peak and overnight base load with a 20 percent depth-of-discharge reserve. Cycle-life modelling at one full equivalent cycle per day projects battery replacement in year 9 of the 20-year project life, and the replacement cost is carried in the financial model at 60 percent of today's pack price, reflecting the observed 4 percent annual decline in lithium iron phosphate costs. The diesel generator is dispatched only when the battery state of charge falls below 25 percent, an event projected to occur on 26 days per year, concentrated in the wet season months of June through August.

### Figure-3.1: Reference microgrid single-line diagram

The figure shows the reference single-line diagram for a mid-sized district microgrid. The 240 kWp photovoltaic array feeds two 75 kW maximum power point tracking charge controllers, which connect to the 520 kWh battery bank on a shared 400 V DC bus. Three parallel 50 kVA bidirectional inverters convert the DC bus to a three-phase 400 V AC distribution bus. The 60 kVA diesel generator connects to the AC bus through a motorized changeover switch, and a 25 kV step-up transformer feeds two medium-voltage distribution feeders running north and south along the main road corridor. Smart meters at each service connection report fifteen-minute interval data over a LoRaWAN backhaul to the operations center.

### Distribution Network

The distribution design uses a hybrid architecture: medium-voltage backbone feeders at 25 kV where load centers are more than 1.8 kilometers apart, and 400 V low-voltage reticulation within villages. Conductor sizing follows a 7 percent maximum voltage drop criterion at projected year-10 peak load. Pole spacing is standardized at 55 meters using locally treated eucalyptus poles, which reduced distribution capital cost by 18 percent relative to imported concrete poles in the pilot procurement. Service connections use ready-boards with integrated miniature circuit breakers rather than full house wiring, cutting connection cost to 74 USD per household and allowing same-day energization after meter installation.

### Page: 4

## Financial Analysis

### Capital and Operating Costs

Total capital expenditure for the nine viable districts is estimated at 6.84 million USD, averaging 1,410 USD per connection. Generation assets account for 52 percent of capital cost, distribution 31 percent, and connections, metering, and project development the remaining 17 percent. Battery storage alone represents 38 percent of total capital expenditure, making it the largest single cost line and the primary target for value engineering. A sensitivity run shows that each 10 percent reduction in battery cost improves the portfolio equity internal rate of return by 0.9 percentage points.

Operating expenditure is projected at 96,000 USD per year across the portfolio, dominated by staffing at 41 percent, diesel fuel at 22 percent, and scheduled maintenance at 19 percent. The staffing model uses a hub-and-spoke arrangement: a central operations team of six covers all nine sites, with one locally recruited agent per district handling customer service, meter issues, and first-line fault response. Remote monitoring reduces required site visits to a monthly preventive maintenance schedule, and the LoRaWAN metering platform automates billing through mobile money integration, which eliminated an estimated 2.1 full-time revenue collection positions per district in the pilot.

### Tariff Design and Subsidy

The proposed tariff schedule recovers full operating costs and 80 percent of capital recovery from customer revenue, with the remaining 20 percent covered by the rural electrification fund capital subsidy. Tariffs are differentiated by service tier as shown in the demand assessment, and all tiers include a lifeline provision: the first 2 kWh per month are billed at half rate for Tier 1 customers. Regulatory approval requires demonstrating that the Tier 1 monthly cost of 5.80 USD remains below the surveyed baseline energy expenditure of 14.60 USD, a condition met in all nine districts. The model projects portfolio-level operating cash flow turning positive in month 31 and cumulative cash flow breakeven in year 12.

### Page: 5

## Risk Assessment and Recommendations

### Principal Risks

Four principal risks dominate the assessment. First, demand risk: if realized consumption falls 25 percent below projection, three of the nine districts drop below debt service coverage of 1.2. The mitigation is anchor-load contracting, securing take-or-pay agreements with agro-processors and telecom operators before financial close. Second, tariff risk: political pressure to cap tariffs below cost-recovery levels has affected 40 percent of microgrid programs in the comparator set. The recommended mitigation is a multi-year tariff framework agreed with the regulator at program launch, indexed to the consumer price index and diesel prices. Third, grid arrival risk: the national utility's densification plan could reach two of the nine districts by 2031, stranding microgrid assets. The study recommends adopting grid-interconnection-ready technical standards so that microgrids can convert to distribution franchisees rather than being displaced. Fourth, foreign exchange risk on battery replacement in year 9, mitigated by a dollar-indexed component in the tariff formula capped at 15 percent of the total tariff.

### Recommendations

The study makes five recommendations. First, proceed to procurement for the nine viable districts in two phases, with the four highest-scoring districts in phase one to establish operational track record before the larger phase two tender. Second, negotiate anchor-load agreements covering at least 25 percent of projected year-one energy sales as a condition precedent to construction. Third, adopt the grid-interconnection-ready standard for all inverters and protection systems, at an incremental capital cost of 2.3 percent. Fourth, establish an appliance financing facility of 400,000 USD to sustain tier migration, recoverable through on-bill repayment. Fifth, defer Kelmara, Tovin Flats, and Upper Reswick to the grid densification program and formally reallocate their subsidy envelope at the mid-term program review, no later than month 18.
