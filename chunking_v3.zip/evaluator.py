"""Component B: retrieval evaluation harness.

Generates per-page specific/broad questions with the Mistral model, embeds
them with the same GTE model and preprocessing as Component A, queries the
FAISS index (read-only, restricted to the source document), and reports
hit@k, MRR and mean/median rank plus per-query latency in a consolidated CSV.
"""

from __future__ import annotations

import json
import re
import statistics
import time
from pathlib import Path

import faiss
import numpy as np
import pandas as pd

from chunker import DEFAULT_TOKENIZER, TokenCounter, build_page_regex

QG_SYSTEM_PROMPT = (
    "You are an expert at writing evaluation questions for document retrieval "
    "systems. You write high-quality questions strictly grounded in the text "
    "you are given, and you respond with valid JSON only."
)

QG_USER_TEMPLATE = """Below is the text of page {page_no} from the document "{doc_name}".

Generate up to {n_specific} SPECIFIC questions and up to {n_broad} BROAD questions about this page.

- SPECIFIC questions: narrow, fact-level questions answerable from a single passage, table, or figure on this page. Include detail-oriented questions about numbers, names, tables or figures where present.
- BROAD questions: higher-level questions that require synthesizing information across multiple passages of this page to understand its main theme, argument, or conclusion.
- Mix factual, inferential, and detail-oriented questions.
- Every question must be answerable strictly from the provided text. Do not use outside knowledge.
- If the page has too little content for the requested number, return fewer questions.

Respond with ONLY this JSON (no markdown fences, no commentary):
{{"specific": ["...", "..."], "broad": ["...", "..."]}}

PAGE TEXT:
<<<
{page_text}
>>>"""


class RetrievalEvaluator:
    """Read-only evaluation harness over the index built by Component A."""

    def __init__(self, config: dict, client, counter: TokenCounter = None):
        self.cfg = config["evaluation"]
        self.chunk_cfg = config["chunking"]
        self.client = client
        self.counter = counter or TokenCounter(DEFAULT_TOKENIZER)
        self.page_re = build_page_regex(self.chunk_cfg["page_tag_pattern"])

        out_dir = Path(self.chunk_cfg["output_dir"])
        index_path = out_dir / self.chunk_cfg["faiss_index_file"]
        meta_path = out_dir / self.chunk_cfg.get("faiss_metadata_file", "faiss_metadata.json")
        if not index_path.exists() or not meta_path.exists():
            raise FileNotFoundError(
                f"Missing '{index_path}' or '{meta_path}'. Run Component A "
                "(chunking) first to build the index."
            )
        # Read-only access: the index is only ever searched, never modified
        # or re-written by this component.
        try:
            self.index = faiss.read_index(str(index_path), faiss.IO_FLAG_READ_ONLY)
        except Exception:
            self.index = faiss.read_index(str(index_path))
        meta = json.loads(meta_path.read_text(encoding="utf-8"))
        self.chunks = meta["chunks"]
        self.parents = meta["parents"]
        if self.index.ntotal != len(self.chunks):
            raise RuntimeError(
                f"Index/metadata mismatch: {self.index.ntotal} vectors vs "
                f"{len(self.chunks)} chunk records."
            )
        self.doc_row_ids = {}
        for row, chunk in enumerate(self.chunks):
            self.doc_row_ids.setdefault(chunk["doc_id"], []).append(row)

    # -------------------------------------------------------------- parsing
    def split_pages(self, text: str) -> list:
        """Split raw Markdown into [(page_no, page_text)] using the page tag.

        Documents without page tags come back as a single page 0, matching
        the page_id Component A assigns in that case.
        """
        pages = []
        current_no, buf = 0, []
        for line in text.splitlines():
            m = self.page_re.match(line)
            if m:
                if "".join(buf).strip():
                    pages.append((current_no, "\n".join(buf).strip()))
                current_no, buf = int(m.group(1)), []
            else:
                buf.append(line)
        if "".join(buf).strip():
            pages.append((current_no, "\n".join(buf).strip()))
        return pages

    # ---------------------------------------------------- question generation
    def generate_questions(self, doc_name: str, page_no: int, page_text: str) -> list:
        """Return [(question, question_type)] for one page; [] on failure."""
        prompt = QG_USER_TEMPLATE.format(
            page_no=page_no,
            doc_name=doc_name,
            n_specific=self.cfg["questions_per_page_specific"],
            n_broad=self.cfg["questions_per_page_broad"],
            page_text=page_text,
        )
        messages = [
            {"role": "system", "content": QG_SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ]
        try:
            raw = self.client.chat(messages)
        except Exception as exc:
            print(f"  ! question generation failed for page {page_no}: {exc}")
            return []
        data = self._parse_json(raw)
        if not isinstance(data, dict):
            print(f"  ! unparseable question JSON for page {page_no}: {raw[:120]!r}")
            return []
        out = []
        for key, qtype, cap in (
            ("specific", "specific", self.cfg["questions_per_page_specific"]),
            ("broad", "broad", self.cfg["questions_per_page_broad"]),
        ):
            val = data.get(key) or []
            if isinstance(val, str):  # model returned a bare string question
                val = [val]
            for q in list(val)[:cap]:
                if isinstance(q, str) and q.strip():
                    out.append((q.strip(), qtype))
        return out

    @staticmethod
    def _parse_json(raw: str):
        raw = re.sub(r"^\s*```(?:json)?|```\s*$", "", raw.strip(), flags=re.MULTILINE)
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            m = re.search(r"\{.*\}", raw, re.DOTALL)
            if m:
                try:
                    return json.loads(m.group(0))
                except json.JSONDecodeError:
                    return None
        return None

    # -------------------------------------------------------------- querying
    def query(self, question: str, doc_id: str):
        """Embed the question and search within its source document.

        Returns (results, latency_seconds) where results are
        [(chunk_dict, score)] for the top-ranked child chunks. When parent
        dedupe is enabled, extra children are fetched so the deduplicated
        parent candidate list can still reach a full top_K entries.
        """
        top_k = int(self.cfg["top_K"])
        if self.cfg.get("dedupe_by_parent", True):
            top_k *= int(self.cfg.get("dedupe_overfetch_factor", 5))
        rows = self.doc_row_ids.get(doc_id, [])
        if not rows:
            return [], 0.0

        t0 = time.perf_counter()
        vec = np.asarray(self.client.embed([question]), dtype=np.float32)
        faiss.normalize_L2(vec)
        results = self._search_in_doc(vec, rows, top_k)
        latency = time.perf_counter() - t0
        return results, latency

    def _search_in_doc(self, vec: np.ndarray, rows: list, k: int) -> list:
        """Search restricted to one document's rows via an ID selector, with
        an exhaustive filter fallback for FAISS builds without selector
        support (never drops in-document results)."""
        k_eff = min(k, len(rows))
        try:
            sel = faiss.IDSelectorBatch(np.asarray(rows, dtype=np.int64))
            params = faiss.SearchParameters(sel=sel)
            scores, ids = self.index.search(vec, k_eff, params=params)
        except Exception:
            row_set = set(rows)
            scores, ids = self.index.search(vec, self.index.ntotal)
            pairs = [(i, s) for i, s in zip(ids[0], scores[0]) if int(i) in row_set]
            return [(self.chunks[int(i)], float(s)) for i, s in pairs[:k_eff]]
        return [
            (self.chunks[int(i)], float(s))
            for i, s in zip(ids[0], scores[0])
            if int(i) >= 0
        ]

    # --------------------------------------------------------------- scoring
    def _rank_results(self, results: list, question_page: int):
        """Collapse child hits to ranked parent candidates and find the rank
        of the first valid page match.

        Returns (candidates, rank) where candidates is
        [(chunk, score)] deduplicated by parent (best child kept) and rank is
        the 1-based rank of the first hit, or None if no hit in the list.
        """
        threshold = float(self.cfg["similarity_threshold"])
        tol = int(self.cfg["neighbour_page_tolerance"])

        if self.cfg.get("dedupe_by_parent", True):
            candidates, seen = [], set()
            for chunk, score in results:
                if chunk["parent_id"] in seen:
                    continue
                seen.add(chunk["parent_id"])
                candidates.append((chunk, score))
            candidates = candidates[: int(self.cfg["top_K"])]
        else:
            candidates = list(results)

        rank = None
        for pos, (chunk, score) in enumerate(candidates, start=1):
            if score < threshold:
                continue
            if abs(int(chunk["page_id"]) - int(question_page)) <= tol:
                rank = pos
                break
        return candidates, rank

    # ------------------------------------------------------------------ run
    def run(self) -> dict:
        data_dir = Path(self.chunk_cfg["data_dir"])
        out_dir = Path(self.chunk_cfg["output_dir"])
        out_dir.mkdir(parents=True, exist_ok=True)
        hit_ks = list(self.cfg.get("hit_k_values", [1, 3, 5, 10]))
        min_page_tokens = int(self.cfg.get("min_page_tokens", 0))
        max_chars = int(self.cfg.get("retrieved_text_max_chars", 0))

        files = []
        for pattern in self.chunk_cfg.get("file_glob", ["*.md"]):
            files.extend(sorted(data_dir.glob(pattern)))
        files = sorted(set(files))

        indexed_docs = set(self.doc_row_ids)
        rows = []
        for path in files:
            doc_id = path.stem
            if doc_id not in indexed_docs:
                print(f"  ! {path.name} not present in the index, skipping")
                continue
            print(f"Evaluating {path.name} ...")
            text = path.read_text(encoding="utf-8-sig", errors="replace")
            for page_no, page_text in self.split_pages(text):
                if min_page_tokens and self.counter.count(page_text) < min_page_tokens:
                    continue
                for question, qtype in self.generate_questions(path.name, page_no, page_text):
                    try:
                        results, latency = self.query(question, doc_id)
                    except Exception as exc:
                        print(f"  ! query failed ({question[:60]!r}): {exc}")
                        continue
                    if not results:
                        print(f"  ! no results returned for {question[:60]!r}, skipping")
                        continue
                    candidates, rank = self._rank_results(results, page_no)
                    top_chunk, top_score = candidates[0]
                    answer = self.parents[top_chunk["parent_id"]]["text"]
                    if max_chars and len(answer) > max_chars:
                        answer = answer[:max_chars] + " ..."
                    row = {
                        "source_file_name": path.name,
                        "question_type": qtype,
                        "question": question,
                        "retrieved_chunk": answer,
                        "question_page_no": page_no,
                        "retrieved_chunk_page_no": top_chunk["page_id"],
                        "similarity_score": round(top_score, 4),
                        "rank": rank,
                    }
                    for k in hit_ks:
                        row[f"hit@{k}"] = int(rank is not None and rank <= k)
                    row["latency"] = round(latency, 4)  # seconds, per spec field name
                    rows.append(row)

        if not rows:
            raise RuntimeError("No evaluation rows produced (no questions generated?).")

        df = pd.DataFrame(rows)
        csv_path = out_dir / self.cfg["results_csv"]
        df.to_csv(csv_path, index=False, encoding="utf-8")

        summary = self._summarize(df, hit_ks)
        summary_path = out_dir / self.cfg.get("summary_file", "evaluation_summary.json")
        summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")

        self._print_summary(summary, csv_path, summary_path)
        return summary

    # -------------------------------------------------------------- summary
    @staticmethod
    def _metrics(df: pd.DataFrame, hit_ks: list) -> dict:
        ranks = df["rank"].dropna().astype(int).tolist()
        reciprocal = [1.0 / r for r in ranks] + [0.0] * int(df["rank"].isna().sum())
        out = {
            "questions": int(len(df)),
            "answered_within_top_k": len(ranks),
            "missed": int(df["rank"].isna().sum()),
            "MRR": round(sum(reciprocal) / len(df), 4) if len(df) else 0.0,
            "mean_rank": round(statistics.mean(ranks), 4) if ranks else None,
            "median_rank": round(statistics.median(ranks), 4) if ranks else None,
            "mean_latency_sec": round(float(df["latency"].mean()), 4),
            "mean_similarity": round(float(df["similarity_score"].mean()), 4),
        }
        for k in hit_ks:
            out[f"hit@{k}"] = round(float(df[f"hit@{k}"].mean()), 4)
        return out

    def _summarize(self, df: pd.DataFrame, hit_ks: list) -> dict:
        summary = {"overall": self._metrics(df, hit_ks), "by_question_type": {}, "by_file": {}}
        for qtype, part in df.groupby("question_type"):
            summary["by_question_type"][qtype] = self._metrics(part, hit_ks)
        for fname, part in df.groupby("source_file_name"):
            summary["by_file"][fname] = self._metrics(part, hit_ks)
        return summary

    @staticmethod
    def _print_summary(summary: dict, csv_path, summary_path):
        o = summary["overall"]
        print("\n=== Retrieval evaluation summary ===")
        print(f"questions evaluated : {o['questions']}  (missed: {o['missed']})")
        for key, val in o.items():
            if key.startswith("hit@"):
                print(f"{key:<20}: {val:.4f}")
        print(f"{'MRR':<20}: {o['MRR']:.4f}")
        print(f"{'mean rank':<20}: {o['mean_rank']}")
        print(f"{'median rank':<20}: {o['median_rank']}")
        print(f"{'mean latency (s)':<20}: {o['mean_latency_sec']}")
        print(f"\nResults CSV : {csv_path}")
        print(f"Summary JSON: {summary_path}")
