### Advanced Document Chunking and Retrieval Evaluation

## Overall Objective

The goal is to implement a smart document chunking system and its retrieval evaluation. The system is consist of two main parts:
- **Component A:** A chunking module that intelligently splits documents into meaningful segments for semantic retrieval.
- **Component B:** An evaluation module that rigorously measures the retrieval efficacy of Component A.

The primary evaluation metric is the retrieval similarity score against a user query, with latency as a secondary metric. The system accuracy will be quantified using standard information retrieval metrics, including hit@k (for k ∈ {1, 3, 5, 10}), Mean Reciprocal Rank (MRR), and the mean/median rank of the correct document page.

## Core Retrieval Model and Challenges

The retrieval process will be based on cosine similarity between the semantic embeddings of a user's question and the document chunks. The design must explicitly mitigate two common failure modes:
1. **Score Dilution:** This occurs when a chunk is too large, causing irrelevant content to dilute the similarity score of the relevant passage within it.
2. **Score Fragmentation:** This happens when a chunk is too small, splitting a complete answer across multiple chunks. This disperses the relevance signal, resulting in lower scores for each fragment and increasing the risk that no single chunk will rank highly enough.

Our chosen design will address this precision/recall tradeoff by decoupling the retrieval unit (the small chunk) from the context unit (the larger parent section).

## Input Data

A data extractor has already extracted the content from pdf into Markdown format. These documents contain tagged structural elements:
- Page numbers (e.g., `### Page: 1`)
- Section headings (e.g., `#`, `##`, `###`, `####`, `#####`)
- Tables (e.g., `### Table-1.1`)
- Figure interpretations in plain text (e.g., `### Figure-1.1`)

I will iterate through each input file from the data folder one file at a time. Please consolidate the outputs for all input files, excluding `<filename>_chunks.txt`, `<filename>_chunks_metadata.json`, and `<filename>_parent_map.txt`. These three output files should be generated separately for each input file, and their filenames should match the corresponding input filename.

---

## Component A: Structure-Aware Chunking

Implement a structure-aware, parent-child ("small-to-big") chunker with contextual breadcrumbs using open-source libraries and the specified `gpt2_tokenizer`.

**Requirements:**
- **Hierarchical Splitting:** First, split the document based on its existing structure (headings, sections). Within each section, further partition the prose into smaller "child" chunks.
- **Child Chunks:** These should consist of one or more sentences, targeting a size of ~320 tokens (configurable, with a hard maximum of 512 tokens). Implement an overlap of ~10-20% at the sentence level (e.g., ~48 tokens, configurable) to ensure answers that span chunk boundaries are captured. The overlap will be optional, 0 tokens means no overlap. This strategy concentrates the relevant signal to prevent score dilution.
- **Parent-Child Linking:** Embed and index the small child chunks. For each child, store a reference to its larger parent section. At query time, a match with a child chunk will return the full parent section, ensuring the complete context is provided and preventing score fragmentation.
- **Contextual Breadcrumbs:** Before embedding, prepend each child chunk's text with its structural breadcrumb (e.g., `Document > Section > Subsection (p.N)`). This leverages the document's structure to enhance retrieval accuracy at no extra latency cost.
- **Atomic Units:** Tables and figures must be treated as atomic chunks and never split. Also a single sentence will not split into 2 child or parent chunks. They should be embedded with their own breadcrumbs to ensure clean matching for table- or figure-specific queries. Similarly, in parent, try not to split a paragraph/sub-section into 2 chunks.
- **Fragment Handling:** Merge any trailing prose fragment smaller than a minimum threshold (e.g., ~64 tokens, configurable) into the preceding child chunk to avoid creating tiny, isolated chunks.
- **Chunk Metadata:** For each child chunk, emit the following metadata: `doc_id`, `kind` (text/table/figure), `raw_text`, `embed_text` (breadcrumb + body), `section_path`, `page_id` (Page number), `parent_id`, and `token_count`. This metadata should be configurable. A separate mapping should store `parent_id` to `parent_section_text`.
- **Vector Storage:** Use FAISS for both storing vector embeddings and performing semantic searches. The `embed_text` will be indexed, while the other fields will be stored as metadata.
- **Page Assignment:** Assign the correct page number/ID to each chunk for use in Component B's evaluation.
- **Output:** Store the generated chunks in plain text file and metadata in JSON file in the specified output folder.
- **Constraint:** We do not use embedding-breakpoint "semantic chunking" methods.
- **Sectionless Text:** If no section headings are identified, combine consecutive paragraphs to create sectionless chunks. Ensure that these chunks do not exceed the specified maximum token length.
- **Page Number Tags:** Remove page tags (e.g., `### Page: {n}`) during chunking, but preserve the page number information in the metadata to maintain the mapping between page numbers and the corresponding parent and child chunks.

This single-pass indexing approach ensures low latency for both indexing and querying.

**Output:**

Write the following files to the output folder:

- `<filename>_chunks.txt` — Contains the generated chunks.
- `<filename>_chunks_metadata.json` — Contains the metadata for each chunk.
- `<filename>_parent_map.txt` — Contains the parent-child chunk mappings.
- `faiss_index.bin` — A single FAISS index file containing embeddings for all chunks across the entire dataset.

---

## Component B: Retrieval Evaluation

This component will measure the retrieval quality of the chunking approach using the vector database of smart chunks populated by Component A.

**Behavior:**
1. **Question Generation:** Load the Markdown text of a document. For each page, generate up to 3 specific and 3 broad questions using the specified text generation model. The questions must be high-quality, strictly based on the provided text, and include a mix of factual, inferential, and detail-oriented (e.g., numbers, names, figures) questions.
2. **Question Tiers:**
   - **Specific Questions:** Narrow, fact-level questions answerable from a specific passage, table, or figure.
   - **Broad Questions:** Higher-level questions requiring synthesis of information across multiple passages to understand the main theme or conclusion.
3. **Embedding:** Embed each question using the same embedding model and preprocessing steps as Component A to ensure vector comparability.
4. **Querying & Latency:** Query the vector database to retrieve the top-k (k value) most similar passages for each question from the document from where the specific question is generated. Use the metadata produced by Component A compare the document names of the chunks with generated question. Record the per-query latency for the combined embedding generation and vector search operation.
5. **Matching & Threshold:** The retrieved parent section(s) will serve as the candidate answer. A configurable similarity threshold and top-k value will determine which retrieved passages are considered valid matches.
6. **Matching & Metrics:** A "hit" is defined as an instance where the `page_id` of the generated question matches with the same or neighbouring `page_id` of the retrieved passage. Compute `hit@k` (for k ∈ {1, 3, 5, 10}).
7. **Consolidated Output:** Write a single, structured output, CSV file, containing the results. Each record should include, at a minimum: `source_file_name`, `question`, `page_no`, `question_type`, `retrieved_answer`, `similarity_score`, `hit@k`, and `latency`. Finally, compute and report the overall MRR and mean/median rank to see the effectiveness of Component A — the chunking approach.

**Outcome:**

Output the following files to the output folder:

- Generate a single, structured output CSV file containing the consolidated results from all input files. Each record must include, at a minimum, the following fields:
  - `source_file_name`
  - `question_type`
  - `question`
  - `retrieved_chunk`
  - `question_page_no`
  - `retrieved_chunk_page_no`
  - `similarity_score`
  - `hit@k`
  - `latency`
- Additionally, compute and report the overall Mean Reciprocal Rank (MRR), as well as the mean and median rank, to evaluate the effectiveness of Component A (the chunking approach).
- A retrieval is considered a hit if the `retrieved_chunk_page_no` is either the same as or adjacent to the `question_page_no` (i.e., the page number matches or differs by one page).

## Design Notes:

- Reuse the configuration and parsing logic from Component A wherever possible to avoid code duplication.
- The evaluation harness must be robust, provide clear configuration options, and handle errors gracefully.
- The harness should operate in read-only mode when accessing the vector database and must not modify the index.
- Keep the implementation simple and maintainable, with one class per component. Use open-source libraries wherever possible (e.g., LangChain) to minimize custom code.
- Read all configurable values from the `config.json` file provided below.
- I will provide you five from where you read config file: R2D2__TOKEN_UR, R2D2__SCOPE, R2D2__GRANT_TYPE, R2D2__VERTEX_PROJECT, R2D2__HOST, R2D2__CLIENT_ID, R2D2__CLIENT_SECRET, REQUESTS__CA_BUNDLE, and SSL_CERT_FILE values.
- Strictly use the following code to obtain token count (gpt2_tokenizer), question generation (Mistral) and embedding model (GTE).

## Non-functional requirements (apply to both components):

- Use langchain or other stable pre-built libraries to minimize the code as much as possible
- Maximizing the retrieval similarity score and hit@k is the primary objective; latency is secondary but must be kept low (single-pass indexing, lightweight query path, per-query latency recorded in evaluation).
- Configurable knobs, with sensible defaults: page-tag pattern, child target/max/min tokens, overlap, breadcrumb on/off, top-k, similarity threshold, questions-per-page caps, folder/output paths, model handles.
- Thoroughly test the system on the sample data before providing the final code. Ensure that all functionality is validated, any issues are identified and resolved, and the code performs as expected before delivery.

---

# Tokenizer Usage — gpt2_tokenizer

Use the following code to obtain token counts:

```python
DEFAULT_TOKENIZER = str(Path(__file__).parent / 'gpt2_tokenizer' / 'gpt2_tokenizer.json')

class TokenCounter:
    def __init__(self, tokenizer_path: str = DEFAULT_TOKENIZER):
        self.tok = Tokenizer.from_file(tokenizer_path)

    def count(self, text: str) -> int:
        return len(self.tok.encode(text).ids) if text else 0

self.counter = TokenCounter(DEFAULT_TOKENIZER)
counter.count(body)
```

***

# Generation Model Usage

Use the following code to obtain embeddings and question generation.

## Authentication

```python
def get_token():
    payload = {
        "client_id": os.environ["R2D2__CLIENT_ID"],
        "client_secret": os.environ["R2D2__CLIENT_SECRET"],
        "grant_type": os.environ["R2D2__GRANT_TYPE"],
        "scope": os.environ["R2D2__SCOPE"],
    }

    resp = requests.post(
        os.environ["R2D2__TOKEN_URL"],
        data=payload,
        verify=os.environ["SSL_CERT_FILE"]
    )

    if resp.ok:
        return resp.json().get("access_token")
    else:
        print(f"Failed to obtain token {resp.status_code} due to {resp.reason}")
```

### Embedding Model — GTE

```python
response = requests.post(
    f"{self.chunking_config['endpoint']}stellar/v1/embeddings",
    headers={
        "Content-Type": "application/json",
        "Authorization": f"Bearer {self.token}"
    },
    json={
        "model": self.chunking_config['embedding_model'],
        "input": batch
    }
)

if response.status_code != 200:
    return None

data = sorted(response.json()["data"], key=lambda x: x["index"])
all_vecs.extend([item["embedding"] for item in data])
```

### Question Generation Model — Mistral

```python
response = requests.post(
    f"{self.chunking_config['endpoint']}stellar/v1/chat/completions",
    headers={
        "Content-Type": "application/json",
        "Authorization": f"Bearer {self.token}"
    },
    json={
        "model": self.chunking_config['model'],
        "messages": Query,
        "temperature": 0.7,
        "max_tokens": 4096,
        "stream": False,
    }
)

response_data = response.json()
```

## config.json

Create this configuration file and use it in the project.

```json
{
    "chunking": {
        "child_target_tokens":   320,
        "child_min_tokens":      64,
        "child_max_tokens":      512,
        "overlap_tokens":        48,
        "parent_max_tokens":     3500,
        "breadcrumb_enabled":    true,
        "page_tag_pattern":      "### Page: {n}",

        "data_dir":              "data",
        "output_dir":            "output",

        "faiss_index_file":      "faiss_index.bin",

        "embedding_batch_size":  32,
        "embedding_model":       "gte-large-en-v1.5",
        "endpoint":              "https://uat.stellar.nam.nsroot.net/"
    },
    "evaluation": {
        "top_K":                    10,
        "similarity_threshold":     0.5,
        "questions_per_page_specific": 3,
        "questions_per_page_broad": 3,
        "neighbour_page_tolerance": 1,
        "hit_k_values":             [1, 3, 5, 10],

        "results_csv":              "evaluation_results.csv",

        "model":                    "mistral-medium-2508",
        "temperature":              0.7,
        "max_tokens":               4096,
        "stream":                   false
    }
}