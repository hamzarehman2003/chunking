# Advanced Document Chunking and Retrieval Evaluation

Structure-aware, parent-child ("small-to-big") chunking of tagged Markdown
documents (Component A) plus a retrieval-evaluation harness reporting hit@k,
MRR, mean/median rank and per-query latency (Component B).

## Layout

| File | Purpose |
|---|---|
| `config.json` | All configurable knobs for both components |
| `chunker.py` | Component A — `StructureAwareChunker` (+ `TokenCounter`) |
| `evaluator.py` | Component B — `RetrievalEvaluator` |
| `stellar_client.py` | Shared Stellar API client (R2D2 auth, GTE embeddings, Mistral chat) + offline mock |
| `main.py` | CLI entry point |
| `gpt2_tokenizer/gpt2_tokenizer.json` | Tokenizer used for all token counting |
| `data/` | Input Markdown files (one output set per file) |
| `output/` | All generated artifacts |

## Setup

```
pip install faiss-cpu tokenizers numpy pandas requests
```

Environment variables required for real (non-mock) runs:

```
R2D2__TOKEN_URL, R2D2__SCOPE, R2D2__GRANT_TYPE, R2D2__CLIENT_ID,
R2D2__CLIENT_SECRET, SSL_CERT_FILE (and/or REQUESTS__CA_BUNDLE)
```

`R2D2__VERTEX_PROJECT` / `R2D2__HOST` are accepted but not needed by this
pipeline (the endpoint comes from `config.json`).

## Run

```
python main.py chunk        # Component A: parse -> chunk -> embed -> FAISS index
python main.py evaluate     # Component B: questions -> query -> metrics CSV
python main.py all          # both in order
python main.py all --mock   # full offline dry-run (no credentials/network)
```

## Outputs (in `output/`)

Per input file:
- `<filename>_chunks.txt` — human-readable child chunks (with breadcrumbs)
- `<filename>_chunks_metadata.json` — chunk metadata (fields configurable via `chunking.metadata_fields`)
- `<filename>_parent_map.txt` — parent sections with their child-chunk ids

Consolidated across all files:
- `faiss_index.bin` — single FAISS index (cosine similarity via normalized inner product)
- `faiss_metadata.json` — index-row-aligned chunk metadata + `parent_id -> parent_text` map
- `evaluation_results.csv` — one row per generated question (source file, type, question, retrieved parent text, pages, similarity, rank, hit@k, latency)
- `evaluation_summary.json` — overall / per-type / per-file hit@k, MRR, mean & median rank, mean latency

## Design

- **Children** are sentence-packed to ~`child_target_tokens` (hard max
  `child_max_tokens` for multi-sentence chunks; a single sentence is never
  split), with optional sentence-level overlap of `overlap_tokens` (0 = off)
  and trailing fragments under `child_min_tokens` merged backwards.
- **Parents** are the enclosing sections (split only at paragraph boundaries
  when they exceed `parent_max_tokens`); retrieval matches children, answers
  return the full parent text (score dilution and fragmentation both avoided).
- **Breadcrumbs** (`Document > Section > Subsection (p.N)`) are prepended to
  each child's `embed_text` (toggle: `breadcrumb_enabled`).
- **Tables and figures** (`### Table-1.1`, `### Figure-1.1`) are atomic chunks
  with their own breadcrumbs; a table continuing across a page tag stays one
  chunk. Tag patterns are configurable regexes.
- **Page tags** (`### Page: {n}`, pattern configurable) are stripped from all
  text but preserved as `page_id` on every chunk and parent.
- **Evaluation** generates up to 3 specific + 3 broad questions per page
  (Mistral), embeds them with the same GTE model, searches only within the
  question's source document, dedupes ranked child hits to parent candidates,
  and counts a hit when the retrieved page is within
  `neighbour_page_tolerance` of the question's page and the score clears
  `similarity_threshold`. The index is opened read-only and never modified.

### Mock mode

`--mock` swaps in a deterministic offline client (hashed bag-of-words
embeddings, grounded template questions) so the entire pipeline — chunking,
FAISS indexing, retrieval, metrics — runs without credentials. Mock cosine
scores are lower than real GTE scores; with the default
`similarity_threshold: 0.5` many mock retrievals are gated out, so for mock
smoke-tests set the threshold to 0. Real GTE runs should keep the default.
