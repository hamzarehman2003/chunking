"""Shared Stellar API client: OAuth token, GTE embeddings and Mistral chat.

Used by both Component A (embeddings for indexing) and Component B
(question generation + query embeddings) so preprocessing and model access
stay identical across the two components.

A deterministic offline ``MockStellarClient`` with the same interface is
provided so the whole pipeline can be exercised without network access or
R2D2 credentials (``--mock`` flag on main.py).
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import time

import numpy as np
import requests

REQUIRED_ENV_VARS = [
    "R2D2__TOKEN_URL",
    "R2D2__SCOPE",
    "R2D2__GRANT_TYPE",
    "R2D2__CLIENT_ID",
    "R2D2__CLIENT_SECRET",
]

RETRYABLE_STATUS = {429, 500, 502, 503, 504}


def missing_env_vars() -> list:
    return [v for v in REQUIRED_ENV_VARS if not os.environ.get(v)]


class StellarClient:
    """Thin client for the Stellar OpenAI-compatible endpoints."""

    def __init__(self, config: dict):
        self.chunking_config = config["chunking"]
        self.eval_config = config["evaluation"]
        self.endpoint = self.chunking_config["endpoint"].rstrip("/") + "/"
        self.token = None
        self.max_retries = 3

    # ------------------------------------------------------------------ auth
    def _verify(self):
        return (
            os.environ.get("SSL_CERT_FILE")
            or os.environ.get("REQUESTS__CA_BUNDLE")
            or os.environ.get("REQUESTS_CA_BUNDLE")
            or True
        )

    def get_token(self):
        payload = {
            "client_id": os.environ["R2D2__CLIENT_ID"],
            "client_secret": os.environ["R2D2__CLIENT_SECRET"],
            "grant_type": os.environ["R2D2__GRANT_TYPE"],
            "scope": os.environ["R2D2__SCOPE"],
        }

        resp = requests.post(
            os.environ["R2D2__TOKEN_URL"],
            data=payload,
            verify=self._verify(),
            timeout=60,
        )

        if resp.ok:
            return resp.json().get("access_token")
        print(f"Failed to obtain token {resp.status_code} due to {resp.reason}")
        return None

    def _ensure_token(self, force: bool = False):
        if self.token is None or force:
            last_err = None
            for attempt in range(self.max_retries):
                try:
                    self.token = self.get_token()
                except requests.exceptions.SSLError as exc:
                    raise RuntimeError(
                        "SSL verification failed while fetching the R2D2 token. "
                        "Check SSL_CERT_FILE / REQUESTS__CA_BUNDLE. "
                        f"Details: {exc}"
                    ) from exc
                except requests.RequestException as exc:
                    last_err = exc
                    self.token = None
                    if attempt < self.max_retries - 1:
                        time.sleep(2 ** attempt)
                    continue
                if self.token:
                    return self.token
                if attempt < self.max_retries - 1:
                    time.sleep(2 ** attempt)
            raise RuntimeError(
                "Could not obtain R2D2 access token; check the R2D2__* "
                f"environment variables and network/SSL configuration. "
                f"Last error: {last_err}"
            )
        return self.token

    # -------------------------------------------------------------- requests
    def _post(self, path: str, body: dict) -> requests.Response:
        """POST with token refresh on 401 and retries on transient errors."""
        self._ensure_token()
        url = f"{self.endpoint}{path}"
        last_err = None
        for attempt in range(self.max_retries):
            try:
                response = requests.post(
                    url,
                    headers={
                        "Content-Type": "application/json",
                        "Authorization": f"Bearer {self.token}",
                    },
                    json=body,
                    verify=self._verify(),
                    timeout=(15, 300),
                )
            except requests.exceptions.SSLError as exc:
                raise RuntimeError(
                    f"SSL verification failed for {url}. Check SSL_CERT_FILE / "
                    f"REQUESTS__CA_BUNDLE. Details: {exc}"
                ) from exc
            except requests.RequestException as exc:
                last_err = exc
                if attempt < self.max_retries - 1:
                    time.sleep(2 ** attempt)
                continue
            if response.status_code == 401 and attempt < self.max_retries - 1:
                self._ensure_token(force=True)
                continue
            if response.status_code in RETRYABLE_STATUS and attempt < self.max_retries - 1:
                time.sleep(2 ** attempt)
                continue
            return response
        raise RuntimeError(f"Request to {url} failed after retries: {last_err}")

    # ------------------------------------------------------------ embeddings
    def embed(self, batch: list) -> list:
        """Embed a batch of texts with the GTE model; returns list of vectors."""
        response = self._post(
            "stellar/v1/embeddings",
            {
                "model": self.chunking_config["embedding_model"],
                "input": batch,
            },
        )
        if response.status_code != 200:
            raise RuntimeError(
                f"Embedding request failed ({response.status_code}): "
                f"{response.text[:300]}"
            )
        data = sorted(response.json()["data"], key=lambda x: x["index"])
        return [item["embedding"] for item in data]

    # ------------------------------------------------------------------ chat
    def chat(self, messages: list) -> str:
        """Chat completion with the Mistral model; returns the message text."""
        response = self._post(
            "stellar/v1/chat/completions",
            {
                "model": self.eval_config["model"],
                "messages": messages,
                "temperature": self.eval_config.get("temperature", 0.7),
                "max_tokens": self.eval_config.get("max_tokens", 4096),
                "stream": self.eval_config.get("stream", False),
            },
        )
        if response.status_code != 200:
            raise RuntimeError(
                f"Chat request failed ({response.status_code}): {response.text[:300]}"
            )
        response_data = response.json()
        return response_data["choices"][0]["message"]["content"]


class MockStellarClient:
    """Offline stand-in for StellarClient (deterministic, no network).

    Embeddings are hashed bag-of-words vectors, so texts sharing vocabulary
    genuinely score higher under cosine similarity — enough signal to
    exercise FAISS indexing, retrieval and every evaluation metric.
    Chat returns grounded questions built from the page text it is given.
    """

    DIM = 384

    def __init__(self, config: dict):
        self.chunking_config = config["chunking"]
        self.eval_config = config["evaluation"]

    def _vec(self, text: str) -> list:
        v = np.zeros(self.DIM, dtype=np.float32)
        words = re.findall(r"[a-z0-9]+", text.lower())
        for i, w in enumerate(words):
            idx = int(hashlib.md5(w.encode()).hexdigest()[:8], 16) % self.DIM
            v[idx] += 1.0
            if i + 1 < len(words):
                big = w + "_" + words[i + 1]
                bidx = int(hashlib.md5(big.encode()).hexdigest()[:8], 16) % self.DIM
                v[bidx] += 0.5
        n = np.linalg.norm(v)
        if n > 0:
            v /= n
        return v.tolist()

    def embed(self, batch: list) -> list:
        return [self._vec(t) for t in batch]

    def chat(self, messages: list) -> str:
        text = messages[-1]["content"]
        m = re.search(r"<<<\n(.*)\n>>>", text, re.DOTALL)
        page = m.group(1) if m else text
        sentences = [
            s.strip()
            for s in re.split(r"(?<=[.!?])\s+", re.sub(r"\s+", " ", page))
            if len(s.split()) >= 8
        ]
        n_spec = self.eval_config.get("questions_per_page_specific", 3)
        n_broad = self.eval_config.get("questions_per_page_broad", 3)
        specific = [
            "What does the document state about the following: "
            + " ".join(s.split()[:14]) + "?"
            for s in sentences[:n_spec]
        ]
        words = re.findall(r"[A-Za-z]{5,}", page)
        keywords = " ".join(dict.fromkeys(words))[:120]
        broad = [
            f"What is the overall theme concerning {keywords}?",
            f"How do the ideas about {' '.join(dict.fromkeys(words[::3]))[:100]} relate?",
            f"What conclusions are drawn regarding {' '.join(dict.fromkeys(words[1::3]))[:100]}?",
        ][:n_broad]
        return json.dumps({"specific": specific, "broad": broad})
