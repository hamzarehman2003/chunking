"""Component A: structure-aware, parent-child ("small-to-big") chunker.

Parses tagged Markdown (page tags, headings, tables, figures) into a section
tree, builds parent sections (context units) and sentence-packed child chunks
(retrieval units) with contextual breadcrumbs, embeds the children with the
GTE model and stores them in a single FAISS index across all input files.
"""

from __future__ import annotations

import json
import re
from pathlib import Path

import faiss
import numpy as np
from tokenizers import Tokenizer

DEFAULT_TOKENIZER = str(Path(__file__).parent / "gpt2_tokenizer" / "gpt2_tokenizer.json")


class TokenCounter:
    def __init__(self, tokenizer_path: str = DEFAULT_TOKENIZER):
        self.tok = Tokenizer.from_file(tokenizer_path)

    def count(self, text: str) -> int:
        return len(self.tok.encode(text).ids) if text else 0


HEADING_RE = re.compile(r"^(#{1,6})\s+(.*\S)\s*$")
BULLET_RE = re.compile(r"^\s*(?:[-*•+]|\d+[.)])\s+")
# Split at whitespace after sentence punctuation (optionally followed by one
# closing quote/bracket, which stays with its sentence).
SENT_SPLIT_RE = re.compile(r"(?:(?<=[.!?])|(?<=[.!?][\"'\)\]]))\s+")


def build_page_regex(pattern: str) -> re.Pattern:
    """Compile a page-tag template such as '### Page: {n}' into a regex."""
    esc = re.escape(pattern.strip())
    esc = esc.replace(re.escape("{n}"), r"(\d+)")
    esc = esc.replace(re.escape(" "), r"\s+")
    return re.compile(r"^\s*" + esc + r"\s*$")


def split_sentences(text: str) -> list:
    """Split prose into sentences (whitespace-normalised, never empty)."""
    text = re.sub(r"\s+", " ", text).strip()
    if not text:
        return []
    return [p.strip() for p in SENT_SPLIT_RE.split(text) if p.strip()]


class StructureAwareChunker:
    """Hierarchical splitter with parent-child linking and breadcrumbs."""

    def __init__(self, config: dict, client, counter: TokenCounter = None):
        self.cfg = config["chunking"]
        self.client = client
        self.counter = counter or TokenCounter(DEFAULT_TOKENIZER)
        self.page_re = build_page_regex(self.cfg["page_tag_pattern"])
        self.table_re = re.compile(self.cfg.get("table_tag_pattern", r"(?i)^table\b"))
        self.figure_re = re.compile(self.cfg.get("figure_tag_pattern", r"(?i)^(figure|fig)\b"))
        self.target = int(self.cfg["child_target_tokens"])
        self.child_min = int(self.cfg["child_min_tokens"])
        self.child_max = int(self.cfg["child_max_tokens"])
        self.overlap = int(self.cfg["overlap_tokens"])
        self.parent_max = int(self.cfg["parent_max_tokens"])
        self.breadcrumbs_on = bool(self.cfg.get("breadcrumb_enabled", True))

    # ------------------------------------------------------------- parsing
    def _tag_kind(self, title: str):
        """Classify a heading title as a tagged 'table'/'figure' or None."""
        if self.table_re.match(title):
            return "table"
        if self.figure_re.match(title):
            return "figure"
        return None

    def parse_document(self, text: str) -> list:
        """Parse tagged Markdown into an ordered list of sections.

        Each section is ``{"path": [titles...], "blocks": [...]}`` where a
        block is ``{"type": "text"|"table"|"figure", "text", "label", "page"}``.
        Page tags are removed but their numbers are carried onto every block.
        Sectionless text (before the first heading, or documents with no
        headings at all) lands in an initial section with an empty path.
        """
        sections = []
        stack = []  # [(level, title)] of open headings
        current = {"path": [], "blocks": []}
        page = 0
        atomic = None  # open table/figure block
        atomic_break = False  # a page tag was seen while the block was open
        para_lines, para_page = [], 0

        def flush_para():
            nonlocal para_lines
            body = " ".join(para_lines).strip()
            if body:
                current["blocks"].append(
                    {"type": "text", "text": body, "label": "", "page": para_page}
                )
            para_lines = []

        def flush_atomic():
            nonlocal atomic, atomic_break
            if atomic is not None:
                body = "\n".join(atomic["lines"]).strip("\n").rstrip()
                current["blocks"].append(
                    {
                        "type": atomic["kind"],
                        "text": body,
                        "label": atomic["label"],
                        "page": atomic["page"],
                    }
                )
                atomic = None
            atomic_break = False

        def prose_line(line: str):
            nonlocal para_lines, para_page
            if not line.strip():
                flush_para()
                return
            if BULLET_RE.match(line):
                # Each bullet becomes its own "sentence" so lists pack cleanly.
                flush_para()
                current["blocks"].append(
                    {"type": "text", "text": line.strip(), "label": "", "page": page}
                )
                return
            if not para_lines:
                para_page = page
            para_lines.append(line.strip())

        for line in text.splitlines():
            pm = self.page_re.match(line)
            if pm:
                # Page tags are stripped; the number is kept for metadata.
                page = int(pm.group(1))
                if atomic is not None:
                    atomic_break = True
                continue

            hm = HEADING_RE.match(line)
            if hm:
                flush_para()
                flush_atomic()
                level, title = len(hm.group(1)), hm.group(2).strip()
                kind = self._tag_kind(title)
                if kind:
                    # Tables/figures are atomic elements inside the current
                    # section, not structural headings.
                    atomic = {"kind": kind, "label": title, "lines": [], "page": page}
                    continue
                if current["blocks"]:
                    sections.append(current)
                stack = [s for s in stack if s[0] < level] + [(level, title)]
                current = {"path": [t for _, t in stack], "blocks": []}
                continue

            if atomic is not None:
                stripped = line.strip()
                if stripped:
                    is_row = stripped.startswith("|")
                    if atomic_break:
                        # Content after a page boundary: only a table that
                        # visibly continues (another row) stays in the block.
                        atomic_break = False
                        if not (atomic["kind"] == "table" and is_row):
                            flush_atomic()
                            prose_line(line)
                            continue
                    elif atomic["kind"] == "table" and atomic.get("rows_seen") and not is_row:
                        # Table body ended; following prose belongs to the section.
                        flush_atomic()
                        prose_line(line)
                        continue
                    if is_row:
                        atomic["rows_seen"] = True
                atomic["lines"].append(line)
                continue

            prose_line(line)

        flush_para()
        flush_atomic()
        if current["blocks"]:
            sections.append(current)
        return sections

    # ------------------------------------------------------------- helpers
    def _block_text(self, block: dict) -> str:
        if block["type"] in ("table", "figure") and block["label"]:
            return f"{block['label']}\n{block['text']}".strip()
        return block["text"]

    def _breadcrumb(self, doc_title: str, path: list, page, label: str = "") -> str:
        parts = [doc_title] + list(path)
        if label:
            parts.append(label)
        return f"{' > '.join(parts)} (p.{page})"

    # ---------------------------------------------------------- chunk build
    def chunk_document(self, text: str, doc_id: str, source_file: str):
        """Return (chunks, parents) for one document."""
        sections = self.parse_document(text)
        parents = {}
        chunks = []

        for sec in sections:
            for group in self._group_blocks(sec["blocks"]):
                parent_id = f"{doc_id}::P{len(parents):04d}"
                parent_text = "\n\n".join(self._block_text(b) for b in group)
                pages = [b["page"] for b in group]
                parents[parent_id] = {
                    "parent_id": parent_id,
                    "doc_id": doc_id,
                    "source_file": source_file,
                    "section_path": " > ".join(sec["path"]),
                    "page_start": min(pages),
                    "page_end": max(pages),
                    "text": parent_text,
                    "token_count": self.counter.count(parent_text),
                    "child_ids": [],
                }
                for chunk in self._build_children(group, sec["path"], doc_id, doc_title=Path(source_file).stem):
                    chunk_id = f"{doc_id}::C{len(chunks):05d}"
                    chunk["chunk_id"] = chunk_id
                    chunk["doc_id"] = doc_id
                    chunk["source_file"] = source_file
                    chunk["parent_id"] = parent_id
                    parents[parent_id]["child_ids"].append(chunk_id)
                    chunks.append(chunk)
        return chunks, parents

    def _group_blocks(self, blocks: list) -> list:
        """Greedily pack a section's blocks into parents <= parent_max tokens.

        Paragraphs, tables and figures are never split across parents; a
        single oversize block becomes a parent on its own.
        """
        groups, cur, cur_tok = [], [], 0
        for block in blocks:
            t = self.counter.count(self._block_text(block))
            if cur and cur_tok + t > self.parent_max:
                groups.append(cur)
                cur, cur_tok = [], 0
            cur.append(block)
            cur_tok += t
        if cur:
            groups.append(cur)
        return groups

    def _build_children(self, blocks: list, path: list, doc_id: str, doc_title: str) -> list:
        """Sentence-pack the prose of one parent group into child chunks and
        emit tables/figures as atomic children."""
        chunks = []
        sent_buf = []  # (sentence, tokens, page)

        def make_chunk(kind, raw_text, page, label=""):
            crumb = self._breadcrumb(doc_title, path, page, label)
            embed_text = f"{crumb}\n{raw_text}" if self.breadcrumbs_on else raw_text
            return {
                "kind": kind,
                "raw_text": raw_text,
                "embed_text": embed_text,
                "section_path": " > ".join(path),
                "page_id": page,
                "token_count": self.counter.count(raw_text),
            }

        def flush_prose():
            nonlocal sent_buf
            for sents, page in self._pack_sentences(sent_buf):
                chunks.append(make_chunk("text", " ".join(s for s, _, _ in sents), page))
            sent_buf = []

        for block in blocks:
            if block["type"] in ("table", "figure"):
                flush_prose()
                chunks.append(
                    make_chunk(block["type"], self._block_text(block), block["page"], block["label"])
                )
            else:
                for s in split_sentences(block["text"]):
                    sent_buf.append((s, self.counter.count(s), block["page"]))
        flush_prose()
        return chunks

    def _pack_sentences(self, sents: list) -> list:
        """Greedy sentence packing: ~target tokens per chunk with a hard
        child_max for multi-sentence chunks, sentence-level overlap, and
        merging of fragments below child_min. A single sentence is never
        split (only a lone sentence may exceed child_max).

        Returns a list of (sentences, page) where sentences is a list of
        (text, tokens, page) and page is the page of the first new sentence.
        """
        if not sents:
            return []
        packed = []  # (list of sent tuples, n_overlap_seeded, page)
        cur, seeded, cur_tok = [], 0, 0
        i = 0
        while i < len(sents):
            s, t, p = sents[i]
            new_count = len(cur) - seeded
            if new_count == 0:
                # Must make progress. If the next sentence would blow the
                # hard max, drop the overlap seeds (they already live in the
                # previous chunk) rather than exceed child_max.
                if cur and cur_tok + t > self.child_max:
                    cur, seeded, cur_tok = [], 0, 0
                cur.append((s, t, p))
                cur_tok += t
                i += 1
                continue
            over_max = cur_tok + t > self.child_max
            over_target = cur_tok + t > self.target and cur_tok >= self.child_min
            if over_max or over_target:
                packed.append((cur, seeded, cur[seeded][2]))
                if self.overlap > 0:
                    tail, tail_tok = [], 0
                    for st in reversed(cur):
                        if tail_tok + st[1] > self.overlap or len(tail) == new_count:
                            break
                        tail.insert(0, st)
                        tail_tok += st[1]
                    cur, seeded, cur_tok = list(tail), len(tail), tail_tok
                else:
                    cur, seeded, cur_tok = [], 0, 0
                continue
            cur.append((s, t, p))
            cur_tok += t
            i += 1
        if len(cur) > seeded:
            packed.append((cur, seeded, cur[seeded][2]))

        # Merge any fragment below child_min into the previous chunk (only
        # its new sentences; overlap seeds are already in the previous chunk)
        # wherever the merge respects the hard max.
        merged = []
        for sents_, seeded_, page_ in packed:
            tok = sum(t for _, t, _ in sents_)
            new_sents = sents_[seeded_:]
            if merged and tok < self.child_min:
                prev_sents, prev_seeded, prev_page = merged[-1]
                prev_tok = sum(t for _, t, _ in prev_sents)
                if prev_tok + sum(t for _, t, _ in new_sents) <= self.child_max:
                    merged[-1] = (prev_sents + new_sents, prev_seeded, prev_page)
                    continue
            merged.append((sents_, seeded_, page_))

        return [(sents_, page) for sents_, _, page in merged]

    # ------------------------------------------------------------- outputs
    def _write_per_file_outputs(self, out_dir: Path, stem: str, chunks: list, parents: dict):
        sep = "=" * 80
        dash = "-" * 80

        lines = []
        for c in chunks:
            lines.append(sep)
            lines.append(
                f"CHUNK {c['chunk_id']} | kind={c['kind']} | page={c['page_id']} "
                f"| tokens={c['token_count']} | parent={c['parent_id']}"
            )
            lines.append(f"section: {c['section_path'] or '(none)'}")
            lines.append(dash)
            lines.append(c["embed_text"])
            lines.append("")
        (out_dir / f"{stem}_chunks.txt").write_text("\n".join(lines), encoding="utf-8")

        fields = self.cfg.get("metadata_fields")
        meta = [
            {k: c[k] for k in fields if k in c} if fields else dict(c)
            for c in chunks
        ]
        (out_dir / f"{stem}_chunks_metadata.json").write_text(
            json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8"
        )

        lines = []
        for p in parents.values():
            lines.append(sep)
            lines.append(
                f"PARENT {p['parent_id']} | pages {p['page_start']}-{p['page_end']} "
                f"| tokens={p['token_count']} | children={len(p['child_ids'])}"
            )
            lines.append(f"section: {p['section_path'] or '(none)'}")
            lines.append(f"child_ids: {', '.join(p['child_ids'])}")
            lines.append(dash)
            lines.append(p["text"])
            lines.append("")
        (out_dir / f"{stem}_parent_map.txt").write_text("\n".join(lines), encoding="utf-8")

    # ----------------------------------------------------------------- run
    def run(self) -> dict:
        """Chunk every file in data_dir, embed all children and build one
        FAISS index (plus consolidated metadata) in output_dir."""
        data_dir = Path(self.cfg["data_dir"])
        out_dir = Path(self.cfg["output_dir"])
        out_dir.mkdir(parents=True, exist_ok=True)

        files = []
        for pattern in self.cfg.get("file_glob", ["*.md"]):
            files.extend(sorted(data_dir.glob(pattern)))
        files = sorted(set(files))
        if not files:
            raise FileNotFoundError(f"No input files found in '{data_dir}'.")

        stems = {}
        for path in files:
            stems.setdefault(path.stem, []).append(path.name)
        dups = {s: n for s, n in stems.items() if len(n) > 1}
        if dups:
            raise RuntimeError(
                "Input files share a stem, which would collide in doc ids and "
                f"per-file outputs: {dups}. Rename the inputs to be unique."
            )

        all_chunks, all_parents = [], {}
        for path in files:
            text = path.read_text(encoding="utf-8-sig", errors="replace")
            doc_id = path.stem
            chunks, parents = self.chunk_document(text, doc_id, path.name)
            if not chunks:
                print(f"  ! {path.name}: no content found, skipped")
                continue
            self._write_per_file_outputs(out_dir, path.stem, chunks, parents)
            all_chunks.extend(chunks)
            all_parents.update(parents)
            print(
                f"  - {path.name}: {len(chunks)} child chunks, "
                f"{len(parents)} parents"
            )

        if not all_chunks:
            raise RuntimeError("No chunks produced from any input file.")

        vectors = self._embed_chunks(all_chunks)
        index = faiss.IndexFlatIP(vectors.shape[1])
        index.add(vectors)
        faiss.write_index(index, str(out_dir / self.cfg["faiss_index_file"]))

        meta = {
            "embedding_model": self.cfg["embedding_model"],
            "dim": int(vectors.shape[1]),
            "chunks": all_chunks,  # row i of the index <-> chunks[i]
            "parents": all_parents,
        }
        (out_dir / self.cfg.get("faiss_metadata_file", "faiss_metadata.json")).write_text(
            json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8"
        )
        print(
            f"Indexed {len(all_chunks)} chunks from {len(files)} file(s) -> "
            f"{out_dir / self.cfg['faiss_index_file']}"
        )
        return meta

    def _embed_chunks(self, chunks: list) -> np.ndarray:
        batch_size = int(self.cfg.get("embedding_batch_size", 32))
        texts = [c["embed_text"] for c in chunks]
        vecs = []
        for i in range(0, len(texts), batch_size):
            batch = texts[i : i + batch_size]
            out = self.client.embed(batch)
            if out is None or len(out) != len(batch):
                raise RuntimeError(
                    f"Embedding batch {i // batch_size} failed "
                    f"(got {0 if out is None else len(out)} of {len(batch)} vectors)."
                )
            vecs.extend(out)
        arr = np.asarray(vecs, dtype=np.float32)
        faiss.normalize_L2(arr)  # cosine similarity via inner product
        return arr
