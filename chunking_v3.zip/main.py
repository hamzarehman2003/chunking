"""Entry point for the chunking + retrieval-evaluation pipeline.

Usage:
    python main.py chunk               # Component A: chunk + embed + build index
    python main.py evaluate            # Component B: generate questions + evaluate
    python main.py all                 # both, in order
    python main.py all --mock          # offline end-to-end run (no credentials)
    python main.py chunk --config my_config.json
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from stellar_client import MockStellarClient, StellarClient, missing_env_vars
from chunker import StructureAwareChunker, TokenCounter
from evaluator import RetrievalEvaluator


def load_config(path: str) -> dict:
    cfg_path = Path(path)
    if not cfg_path.exists():
        sys.exit(f"Config file not found: {cfg_path}")
    return json.loads(cfg_path.read_text(encoding="utf-8"))


def build_client(config: dict, mock: bool):
    if mock:
        print("Running in MOCK mode: deterministic offline embeddings/questions.")
        return MockStellarClient(config)
    missing = missing_env_vars()
    if missing:
        sys.exit(
            "Missing required environment variables for the Stellar API:\n  "
            + "\n  ".join(missing)
            + "\nSet them (plus SSL_CERT_FILE / REQUESTS__CA_BUNDLE) or use --mock."
        )
    import os
    if not os.environ.get("SSL_CERT_FILE") and not os.environ.get("REQUESTS__CA_BUNDLE"):
        print(
            "Warning: neither SSL_CERT_FILE nor REQUESTS__CA_BUNDLE is set; "
            "falling back to the system CA bundle. Internal endpoints will "
            "fail SSL verification without the corporate CA bundle."
        )
    return StellarClient(config)


def main():
    parser = argparse.ArgumentParser(description="Structure-aware chunking and retrieval evaluation.")
    parser.add_argument("command", choices=["chunk", "evaluate", "all"], help="Which component to run.")
    parser.add_argument("--config", default="config.json", help="Path to config.json.")
    parser.add_argument("--mock", action="store_true",
                        help="Use the offline mock client (no network/credentials needed).")
    args = parser.parse_args()

    config = load_config(args.config)
    client = build_client(config, args.mock)
    counter = TokenCounter()

    try:
        if args.command in ("chunk", "all"):
            print("=== Component A: chunking + indexing ===")
            StructureAwareChunker(config, client, counter).run()
        if args.command in ("evaluate", "all"):
            print("\n=== Component B: retrieval evaluation ===")
            RetrievalEvaluator(config, client, counter).run()
    except (FileNotFoundError, RuntimeError) as exc:
        sys.exit(f"Error: {exc}")


if __name__ == "__main__":
    main()
